from django.urls import include, path

# Load demo plotly apps - this triggers their registration
import DCAssistChart.DashComponents.forecastvolumes
import DCAssistChart.DashComponents.multiplewell
import DCAssistChart.DashComponents.prodqaqc
import DCAssistChart.DashComponents.prodqaqcwelltestdata
import DCAssistChart.DashComponents.uniquewellratevsdate
import DCAssistChart.DashComponents.uniquewellratevscum
import DCAssistChart.DashComponents.uniquewelldivscasewelllevel
import DCAssistChart.DashComponents.uniquewellbparametervscasewelllevel
import DCAssistChart.DashComponents.uniquewell

from .views import forecastmultiplewells_view, forecastmultiplewellsallwells_view, forecastuniquewellratevsdate_view, forecastuniquewellallwellsratevsdate_view, forecastuniquewellratevscum_view, forecastuniquewellallwellsratevscum_view, forecastuniquewelldivscasewelllevel_view, forecastuniquewellallwellsdivscasewelllevel_view, forecastuniquewellbparametervscasewelllevel_view, forecastuniquewellallwellsbparametervscasewelllevel_view, forecastuniquewell_view, forecastuniquewellallwells_view, forecastvolumes_view, forecastvolumesallwells_view, prodqaqc_view, prodqaqcwelltestdata_view

app_name = 'DCAssistChart'
urlpatterns = [

    path('forecastmultiplewells/', forecastmultiplewells_view,name='multiplewells'),
    path('forecastmultiplewellsallwells/',forecastmultiplewellsallwells_view,name='multiplewellallwells'),

    path('forecastuniquewellratevsdate/',forecastuniquewellratevsdate_view,name='forecastuniquewellratevsdate'),
    path('forecastuniquewellallwellsratevsdate/',forecastuniquewellallwellsratevsdate_view,name='forecastuniquewellallwellsratevsdate'),
    path('forecastuniquewellratevscum/',forecastuniquewellratevscum_view,name='forecastuniquewellratevscum'),
    path('forecastuniquewellallwellsratevscum/',forecastuniquewellallwellsratevscum_view,name='forecastuniquewellallwellsratevscum'),
    path('forecastuniquewelldivscasewelllevel/',forecastuniquewelldivscasewelllevel_view,name='forecastuniquewelldivscasewelllevel'),
    path('forecastuniquewellallwellsdivscasewelllevel/',forecastuniquewellallwellsdivscasewelllevel_view,name='forecastuniquewellallwellsdivscasewelllevel'),
    path('forecastuniquewellbparametervscasewelllevel/',forecastuniquewellbparametervscasewelllevel_view,name='forecastuniquewellbparametervscasewelllevel'),
    path('forecastuniquewellallwellsbparametervscasewelllevel/',forecastuniquewellallwellsbparametervscasewelllevel_view,name='forecastuniquewellallwellsbparametervscasewelllevel'),
    path('forecastuniquewell/', forecastuniquewell_view, name="uniquewell"),
    path('forecastuniquewellallwells/', forecastuniquewellallwells_view, name="uniquewell"),

    path('forecastvolumes/', forecastvolumes_view, name='forecastvolumes'),
    path('forecastvolumesallwells/', forecastvolumesallwells_view, name='forecastvolumesallwells'),


    path('prodqaqc/', prodqaqc_view, name='prodqaqc'),
    path('prodqaqcwelltestdata/', prodqaqcwelltestdata_view, name='prodqaqcwelltestdata'),


    
]