from DCAssistChart.dbqueries import get_prodqaqcwelltestdata_datavalidation_productiondata, get_prodqaqcwelltestdata_datavalidation_welldata
from DCAssistChart.PlotlyComponents.utils.ploty_constant import PRODQAQCWELLTESTDATA
from DCAssistChart.PlotlyComponents.utils.df_queries import create_df, modify_prodqaqcwelltestdata_datavalidation_prod_df, modify_prodqaqcwelltestdata_datavalidation_well_df
from DCAssistChart.PlotlyComponents.plot_figures.prodqaqcwelltestdata_plot_figure import prodqaqcwelltestdata_datavalidation_plot_figure, get_data_not_found_fig


def prodqaqcwelltestdata_datavalidation(dropdown_value,prodqaqcwelltestdata_data):
    if dropdown_value in prodqaqcwelltestdata_data['uniqueids']:
        prodqaqcwelltestdata_datavalidation_productiondata = get_prodqaqcwelltestdata_datavalidation_productiondata(assetdb = prodqaqcwelltestdata_data['assetdb'], uniqueid = prodqaqcwelltestdata_data['uniqueids'])
        
        df_prod = create_df(list(prodqaqcwelltestdata_datavalidation_productiondata))

        df_prod = modify_prodqaqcwelltestdata_datavalidation_prod_df(df_prod)

        prodqaqcwelltestdata_datavalidation_welldata = get_prodqaqcwelltestdata_datavalidation_welldata(assetdb = prodqaqcwelltestdata_data['assetdb'], uniqueid = prodqaqcwelltestdata_data['uniqueids'])

        df_well = create_df(list(prodqaqcwelltestdata_datavalidation_welldata))

        df_well = modify_prodqaqcwelltestdata_datavalidation_well_df(df_well)

        fig = prodqaqcwelltestdata_datavalidation_plot_figure(df_prod, df_well, prodqaqcwelltestdata_data = prodqaqcwelltestdata_data, units = prodqaqcwelltestdata_data['units'], plot_name='prodqaqcwelltestdatadatavalidation')

        return fig

    else:
        return get_data_not_found_fig(title= PRODQAQCWELLTESTDATA['prodqaqcwelltestdatadatavalidation']['title'])
