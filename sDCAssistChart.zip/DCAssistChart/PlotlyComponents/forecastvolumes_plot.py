from runalgorithm.helper import get_run_dir
from DCAssistChart.PlotlyComponents.utils.ploty_constant import INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV, FORECASTVOLUMNES, P_CASE_WELL_LEVEL_ALLCASES
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.df_queries import get_integrated_output_df, rename_columncontent_df, get_filtered_df_multiple_dropdown, empty_df, groupbysum_df, dropna_df, start_to_end_dates_df, sort_df, list_unique_string_in_col, list_unique_rowsname_in_col, dict_to_df
from DCAssistChart.PlotlyComponents.plot_figures.forecastvolumes_plot_figure import get_data_not_found_fig, forecastvolumes_totalprodvsuniqueid_plot_figure

def forecastvolumes_totalprodvsuniqueid(dropdown_value, forecastvolumes_data, startdate, enddate):
    if dropdown_value != None:

        df = empty_df()

        for uniqueid,path in forecastvolumes_data.get('uniqueids').items():

            runid, well_type = path.split(',')

            file_name = INTEGRATED_OUTPUT_CSV

            p_case_well_levels_list = FORECASTVOLUMNES['forecastvolumestotalprodvsuniqueid']['PCase_well_filter']
            if forecastvolumes_data["allcases"] == True:
                p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES
                file_name = INTEGRATED_OUTPUT_FULL_CSV

            path = get_run_dir(forecastvolumes_data['assetdb'], runid)
            integrated_output_path = get_file_path(path,file_name)
            
            df_dropdownvalue = get_integrated_output_df(integrated_output_path, FORECASTVOLUMNES['forecastvolumestotalprodvsuniqueid']['use_colunms'])

            df_dropdownvalue = rename_columncontent_df(df_dropdownvalue)

            df_dropdownvalue = start_to_end_dates_df(df_dropdownvalue, startdate, enddate)

            if not df_dropdownvalue.empty:
                df = df.append(df_dropdownvalue)
            else:
                continue
        
        uniqueids_list = list_unique_rowsname_in_col(df, col_name="UNIQUEID")

        benchmark_case_well_levels_list = sorted(list_unique_string_in_col(df, col_name = "Case_well_level", string_startwith = "Benchmark"))

        case_well_levels_list = p_case_well_levels_list + benchmark_case_well_levels_list

        case_well_levels_dict = {}
        for index, value in enumerate(case_well_levels_list):
            p_case_well_levels_filter_df = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [case_well_levels_list[index]])
            p_case_well_levels_filter_df = sort_df(p_case_well_levels_filter_df, ['Date'])

            temp_dict = {'Cumulative':[],'Case_well_level':[]}            
            for unique_case_level_well in uniqueids_list:
                p_case_and_uniqueid_filter_df = get_filtered_df_multiple_dropdown(p_case_well_levels_filter_df, col_name = 'UNIQUEID', _filters = [unique_case_level_well])
                p_case_and_uniqueid_filter_df = sort_df(p_case_and_uniqueid_filter_df, ['Date'])

                temp_dict['Cumulative'].append(float(p_case_and_uniqueid_filter_df.tail(1).Cumulative.values - p_case_and_uniqueid_filter_df.head(1).Cumulative.values))
                temp_dict['Case_well_level'].append(unique_case_level_well)
                case_well_levels_dict[value] = temp_dict

        fig = forecastvolumes_totalprodvsuniqueid_plot_figure(case_well_levels_dict, uniqueids_list, units = forecastvolumes_data['units'], plot_name='forecastvolumestotalprodvsuniqueid')

        return fig

    else:
        return get_data_not_found_fig(title= FORECASTVOLUMNES['forecastvolumestotalprodvsuniqueid']['title'])
