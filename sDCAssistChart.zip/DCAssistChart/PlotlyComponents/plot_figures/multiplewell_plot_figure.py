from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import scatter_plot, graph_layout, data_not_found_fig, bar_plot
from DCAssistChart.PlotlyComponents.utils.ploty_constant import  COLOR_MAPPING_DICT, MULTIPLEWELL

import plotly.graph_objects as go

def get_data_not_found_fig(title):
    fig = go.Figure()
    fig = data_not_found_fig(fig, title)
    return fig


def multiplewell_datecumvsrate_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, df_history, units, plot_name):

    data = []

    for index, value in enumerate(p_case_well_levels_list):

        if not df_p_case_well_levels_list[index].empty:
            trace_PCaseWellLevels = scatter_plot(data_frame = df_p_case_well_levels_list[index], x=MULTIPLEWELL[plot_name]['x_axis_dfcol'], y=MULTIPLEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_PCaseWellLevels)
    
    for index, value in enumerate(benchmark_case_well_levels_list):

        if not df_benchmark_case_well_levels_list[index].empty:
            trace_BenchmarkForecast = scatter_plot(data_frame = df_benchmark_case_well_levels_list[index], x=MULTIPLEWELL[plot_name]['x_axis_dfcol'], y=MULTIPLEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_BenchmarkForecast)
    
    if not df_history.empty:
        trace_history = scatter_plot(data_frame=df_history,x=MULTIPLEWELL[plot_name]['x_axis_dfcol'], y=MULTIPLEWELL[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['History'],name="History",mode='markers')
        data.append(trace_history)

    xaxis_title = MULTIPLEWELL[plot_name]['x_axis_title']
    yaxis_title = MULTIPLEWELL[plot_name]['y_axis_title']
    if units:
        if plot_name=="multipleratevscum":
            xaxis_title = xaxis_title + "("+units['volume_oil']+")"
        yaxis_title = yaxis_title + "("+units['rate_oil']+")"

    layout = graph_layout(legend_title= MULTIPLEWELL[plot_name]['legend_title'], title = MULTIPLEWELL[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

    fig = go.Figure(data=data,layout=layout)

    return fig


def multiplewell_totalproductionvscasewelllevel_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, units, plot_name):

    data = []

    for index, value in enumerate(p_case_well_levels_list):

        if not df_p_case_well_levels_list[index].empty:
            trace_PCaseWellLevels = bar_plot(data_frame = df_p_case_well_levels_list[index], x=MULTIPLEWELL[plot_name]['x_axis_dfcol'], y=MULTIPLEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_PCaseWellLevels)

    for index, value in enumerate(benchmark_case_well_levels_list):

        if not df_benchmark_case_well_levels_list[index].empty:
            trace_BenchmarkForecast = bar_plot(data_frame = df_benchmark_case_well_levels_list[index], x=MULTIPLEWELL[plot_name]['x_axis_dfcol'], y=MULTIPLEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_BenchmarkForecast)

    xaxis_title = MULTIPLEWELL[plot_name]['x_axis_title']
    yaxis_title = MULTIPLEWELL[plot_name]['y_axis_title']
    if units:
        yaxis_title = yaxis_title + "("+units['volume_oil']+")"
 
    layout = graph_layout(legend_title= MULTIPLEWELL[plot_name]['legend_title'], title = MULTIPLEWELL[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

    fig = go.Figure(data=data,layout=layout)

    return fig