from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import line_plot, scatter_plot, graph_layout, get_fig_with_line_plot, add_yaxis2_layout, bar_plot, data_not_found_fig
from DCAssistChart.PlotlyComponents.utils.ploty_constant import  COLOR_MAPPING_DICT, UNIQUEWELL

import plotly.graph_objects as go

def get_data_not_found_fig(title):
    fig = go.Figure()
    fig = data_not_found_fig(fig, title)
    return fig

def uniquewell_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,df_history,df_decline_period,well_type, df_selected_outlier, df_used_outlier, units, plot_name):

    data = []

    for index, value in enumerate(p_case_well_levels_list):
        if not df_p_case_well_levels_list[index].empty:
            trace_PCaseWellLevels = scatter_plot(data_frame = df_p_case_well_levels_list[index], x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_PCaseWellLevels)
    
    if not df_history.empty:
        trace_history = scatter_plot(data_frame=df_history,x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['History'],name="History",mode='markers')
        data.append(trace_history)
        
    if not df_selected_outlier.empty:
        trace_history = scatter_plot(data_frame=df_selected_outlier,x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Selected_Outlier'],name="Selected-Outlier",mode='markers')
        data.append(trace_history)

    if not df_used_outlier.empty:
        trace_history = scatter_plot(data_frame=df_used_outlier,x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Used_Outlier'],name="Used-Outlier",mode='markers')
        data.append(trace_history)

    xaxis_title = UNIQUEWELL[plot_name]['x_axis_title']
    yaxis_title = UNIQUEWELL[plot_name]['y_axis_title'] 
    if units:
        yaxis_title = yaxis_title + "("+units['volume_oil']+")"

    layout = graph_layout(legend_title= UNIQUEWELL[plot_name]['legend_title'], title = UNIQUEWELL[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

    if well_type == 'PD':
        trace_decline_period = scatter_plot(data_frame = df_decline_period, x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y2_axis_dfcol'], color=COLOR_MAPPING_DICT['Decline_Period'], name = 'Decline-Period', yaxis="y2")
        data.append(trace_decline_period)
        layout.yaxis2 = add_yaxis2_layout(title=UNIQUEWELL[plot_name]['y2_axis_title'])

    fig = go.Figure(data=data,layout=layout)

    return fig

def uniquewell_di_and_b_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, plot_name):
    
    data = []

    for index, value in enumerate(p_case_well_levels_list):
        if not df_p_case_well_levels_list[index].empty:
            trace_PCaseWellLevels = bar_plot(data_frame = df_p_case_well_levels_list[index], x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_PCaseWellLevels)

    layout = graph_layout(legend_title= UNIQUEWELL[plot_name]['legend_title'], title = UNIQUEWELL[plot_name]['title'], xaxis = UNIQUEWELL[plot_name]['x_axis_title'], yaxis = UNIQUEWELL[plot_name]['y_axis_title'])
    
    fig = go.Figure(data=data,layout=layout)

    return fig

def uniquewell_totalproductionvscasewelllevel_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, units, plot_name):

    data = []

    for index, value in enumerate(p_case_well_levels_list):
        if not df_p_case_well_levels_list[index].empty:
            trace_PCaseWellLevels = bar_plot(data_frame = df_p_case_well_levels_list[index], x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_PCaseWellLevels)

    for index, value in enumerate(benchmark_case_well_levels_list):

        if not df_benchmark_case_well_levels_list[index].empty:
            trace_BenchmarkForecast = bar_plot(data_frame = df_benchmark_case_well_levels_list[index], x=UNIQUEWELL[plot_name]['x_axis_dfcol'], y=UNIQUEWELL[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_BenchmarkForecast)

    xaxis_title = UNIQUEWELL[plot_name]['x_axis_title']
    yaxis_title = UNIQUEWELL[plot_name]['y_axis_title']
    if units:
        yaxis_title = yaxis_title + "("+units['volume_oil']+")"
 
    layout = graph_layout(legend_title= UNIQUEWELL[plot_name]['legend_title'], title = UNIQUEWELL[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

    fig = go.Figure(data=data,layout=layout)

    return fig