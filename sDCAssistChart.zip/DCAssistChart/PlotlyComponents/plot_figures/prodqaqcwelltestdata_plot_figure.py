from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import scatter_plot, graph_layout, data_not_found_fig, add_yaxis2_layout
from DCAssistChart.PlotlyComponents.utils.ploty_constant import  COLOR_MAPPING_DICT, PRODQAQCWELLTESTDATA

import plotly.graph_objects as go

def get_data_not_found_fig(title):
    fig = go.Figure()
    fig = data_not_found_fig(fig, title)
    return fig

def prodqaqcwelltestdata_datavalidation_plot_figure(df_prod, df_well, prodqaqcwelltestdata_data, units, plot_name):
    data = []

    if prodqaqcwelltestdata_data['cluster'] == 'oil':
        if not df_prod.empty:
            trace_prodqaqcwelltestdata_cluster_oil= scatter_plot(data_frame=df_prod, x=PRODQAQCWELLTESTDATA[plot_name]['x_axis_dfcol'], y=PRODQAQCWELLTESTDATA[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Allocated_Oil_Rate'],name=PRODQAQCWELLTESTDATA[plot_name]['y_axis_title_oil'],mode='markers')
            data.append(trace_prodqaqcwelltestdata_cluster_oil)
        # else:
        #     trace_prodqaqc_cluster_gas = scatter_plot(data_frame=df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Allocated_Gas_Rate'],name=PRODQAQC[plot_name]['y_axis_title_oil'],mode='markers')
        #     data.append(trace_prodqaqc_cluster_gas)

        xaxis_title = PRODQAQCWELLTESTDATA[plot_name]['x_axis_title']
        yaxis_title = PRODQAQCWELLTESTDATA[plot_name]['y_axis_title_oil']
        if units:
            yaxis_title = yaxis_title + "("+units['rate_oil']+")"

        layout = graph_layout(legend_title= PRODQAQCWELLTESTDATA[plot_name]['legend_title'], title = PRODQAQCWELLTESTDATA[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

        fig = go.Figure(data=data,layout=layout)

    return fig


# PRODQAQCWELLTESTDATA = {

#     'prodqaqcwelltestdatadatavalidation' : {
#         'legend_title' : 'Prodqaaqcwelltestdata Paramters',
#         'title': 'Production History QA-QC: Validation with well test data',
#         'x_axis_dfcol' : 'M_DATE',
#         'y_axis_dfcol' : 'OIL',
#         'y2_axis_dfcol' : 'THP',
#         'y3_axis_dfcol' : 'Choke',
#         'x_axis_title'  : 'Date',
#         'y_axis_title_oil'  : 'Allocated Oil Rate',
#         'y_axis_title_gas'  : 'Allocated Oil Gas',
#         'y2_axis_title' : 'Tubing Head Pressue',
#         'y3_axis_title' : 'Choke'
#     },

# }
