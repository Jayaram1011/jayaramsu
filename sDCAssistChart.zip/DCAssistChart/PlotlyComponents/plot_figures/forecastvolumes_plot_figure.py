from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import scatter_plot, graph_layout, data_not_found_fig, bar_plot_barode_group
from DCAssistChart.PlotlyComponents.utils.ploty_constant import  COLOR_MAPPING_DICT, FORECASTVOLUMNES

import plotly.graph_objects as go

def get_data_not_found_fig(title):
    fig = go.Figure()
    fig = data_not_found_fig(fig, title)
    return fig

def forecastvolumes_totalprodvsuniqueid_plot_figure(case_well_levels_dict, uniqueids_list, units, plot_name):

    data = []

    for index, value in enumerate(case_well_levels_dict):

        if len(case_well_levels_dict[value]['Cumulative']) != 0:

            trace_case_well_case = bar_plot_barode_group(x=uniqueids_list, y=case_well_levels_dict[value]['Cumulative'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_case_well_case)

    xaxis_title = FORECASTVOLUMNES[plot_name]['x_axis_title']
    yaxis_title = FORECASTVOLUMNES[plot_name]['y_axis_title']
    if units:
        yaxis_title = yaxis_title + "("+units['volume_oil']+")"
 
    layout = graph_layout(legend_title= FORECASTVOLUMNES[plot_name]['legend_title'], title = FORECASTVOLUMNES[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title, barmode='group')

    fig = go.Figure(data=data,layout=layout)

    return fig
