from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import scatter_plot, graph_layout, data_not_found_fig, add_yaxis2_layout
from DCAssistChart.PlotlyComponents.utils.ploty_constant import  COLOR_MAPPING_DICT, PRODQAQC

import plotly.graph_objects as go

def get_data_not_found_fig(title):
    fig = go.Figure()
    fig = data_not_found_fig(fig, title)
    return fig

def prodqaqc_ratechokethpvsdate_plot_figure(df, prodqaqc_data, units, plot_name):

    data = []

    if not df.empty:
        if prodqaqc_data['cluster'] == 'oil':
            trace_prodqaqc_cluster_oil= scatter_plot(data_frame=df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Allocated_Oil_Rate'],name=PRODQAQC[plot_name]['y_axis_title_oil'],mode='markers')
            data.append(trace_prodqaqc_cluster_oil)
        else:
            trace_prodqaqc_cluster_gas = scatter_plot(data_frame=df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Allocated_Gas_Rate'],name=PRODQAQC[plot_name]['y_axis_title_oil'],mode='markers')
            data.append(trace_prodqaqc_cluster_gas)

    xaxis_title = PRODQAQC[plot_name]['x_axis_title']
    yaxis_title = PRODQAQC[plot_name]['y_axis_title_oil']
    if units:
        yaxis_title = yaxis_title + "("+units['rate_oil']+")"

    layout = graph_layout(legend_title= PRODQAQC[plot_name]['legend_title'], title = PRODQAQC[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

    if not df.empty:
        trace_thp = scatter_plot(data_frame = df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y2_axis_dfcol'], color=COLOR_MAPPING_DICT['THP'], name = PRODQAQC[plot_name]['y2_axis_title'], yaxis="y2")
        data.append(trace_thp)
        layout.yaxis2 = add_yaxis2_layout(title=PRODQAQC[plot_name]['y2_axis_title'])

    if not df.empty:
        trace_choke = scatter_plot(data_frame = df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y3_axis_dfcol'], color=COLOR_MAPPING_DICT['Choke'], name = PRODQAQC[plot_name]['y3_axis_title'], yaxis="y3")
        data.append(trace_choke)
        layout.yaxis3 = add_yaxis2_layout(title=PRODQAQC[plot_name]['y3_axis_title'])

    fig = go.Figure(data=data,layout=layout)

    return fig


def prodqaqc_rategorwcvsdate_plot_figure(df, prodqaqc_data, units, plot_name):

    data = []

    if prodqaqc_data['cluster'] == 'oil':
        if not df.empty:
            trace_prodqaqc_cluster_oil= scatter_plot(data_frame=df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Oil'],name=PRODQAQC[plot_name]['y_axis_title'],mode='markers')
            data.append(trace_prodqaqc_cluster_oil)

        xaxis_title = PRODQAQC[plot_name]['x_axis_title']
        yaxis_title = PRODQAQC[plot_name]['y_axis_title']
        if units:
            yaxis_title = yaxis_title + "("+units['rate_oil']+")"

        layout = graph_layout(legend_title= PRODQAQC[plot_name]['legend_title'], title = PRODQAQC[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

        if not df.empty:
            trace_wc = scatter_plot(data_frame = df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y2_axis_dfcol'], color=COLOR_MAPPING_DICT['Wc'], name = PRODQAQC[plot_name]['y2_axis_title'], yaxis="y2")
            data.append(trace_wc)
            layout.yaxis2 = add_yaxis2_layout(title=PRODQAQC[plot_name]['y2_axis_title'])

        if not df.empty:
            trace_gor = scatter_plot(data_frame = df, x=PRODQAQC[plot_name]['x_axis_dfcol'], y=PRODQAQC[plot_name]['y3_axis_dfcol'], color=COLOR_MAPPING_DICT['Gor'], name = PRODQAQC[plot_name]['y3_axis_title'], yaxis="y3")
            data.append(trace_gor)
            y3axis_title = PRODQAQC[plot_name]['y3_axis_title']
            if units:
                y3axis_title = y3axis_title + "("+units['phase_gor']+")"
            layout.yaxis3 = add_yaxis2_layout(title=y3axis_title)

        fig = go.Figure(data=data,layout=layout)

        return fig
    
    else:
        return get_data_not_found_fig(title= PRODQAQC['prodqaqcrategorwcvsdate']['title'])