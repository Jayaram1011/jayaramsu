import logging
import pandas as pd
from DCAssistChart.PlotlyComponents.utils.helper import file_exist

logger = logging.getLogger(__name__)

def get_df_colmn_parse_by_date(file_path, usecols):
    return pd.read_csv(file_path, parse_dates=['Date'], usecols=usecols)

def get_integrated_output_df(path, use_colunms):
    try:
        df = pd.DataFrame()
        if file_exist(path):
            df = get_df_colmn_parse_by_date(path, use_colunms)
        return df
    except Exception as e:
        logger.error(e, exc_info=True)

def get_filtered_df(df, uniqueid, _filters):
    df = df[df['Case_well_level'].isin(_filters)]
    filtered_df = df[df.UNIQUEID == uniqueid]
    return filtered_df

def get_filtered_df_multiple_dropdown(df, col_name, _filters):
    df = df[df[col_name].isin(_filters)]
    return df

def rename_columncontent_df(df):
    df['Case_well_level'] = df['Case_well_level'].str.replace('P5_well_level_indx', 'P05_well_level_indx').str.replace('_well_level_indx', '')
    return df

def get_outlier_history_df(path, use_colunms):
    df = pd.DataFrame()
    if file_exist(path):
        df = get_df_colmn_parse_by_date(path, use_colunms)
        return df[df.Case_well_level == 'History']
    return df

def empty_df():
    df = pd.DataFrame()
    return df

def create_df(data_list):
    return pd.DataFrame(list(data_list))

def di_calc_update(df):
    df['Di'] = df['Di'].fillna(0)
    df['Di'] = df['Di'] * 100
    df['Di'] = df['Di'].round(2)
    df = df[['Case_well_level', 'Di', 'UNIQUEID']].drop_duplicates()
    return df

def b_calc_update(df):
    df['b'] = df['b'].fillna(0)
    df['b'] = df['b'].round(2)
    df = df[['Case_well_level', 'b', 'UNIQUEID']].drop_duplicates()
    return df

def dropna_df(df, col_name):
    return df.dropna(subset=[col_name],inplace=False)

def groupbysum_df(df, col_list):
    return df.groupby(col_list).sum().reset_index()

def sort_df(df, col_name):
    return df.sort_values(by=col_name)

def dict_to_df(dict_name):
    return pd.DataFrame.from_dict(dict_name)

def list_unique_string_in_col(df, col_name, string_startwith):
    return [x for x in df[col_name].unique() if x.startswith(string_startwith)]

def list_unique_rowsname_in_col(df, col_name):
    return eval("df." + col_name + ".unique().tolist()")

def start_to_end_dates_df(df, startdate, enddate):
    if startdate != None and enddate != None:
        enddate = pd.to_datetime(enddate) + pd.offsets.MonthEnd()
        mask = (df['Date'] > startdate) & (df['Date'] <= enddate)
        df = df.loc[mask]
    elif startdate != None and enddate == None:
        mask = (df['Date'] > startdate) 
        df = df.loc[mask]
    elif startdate == None and enddate != None:
        enddate = pd.to_datetime(enddate) + pd.offsets.MonthEnd()
        mask = (df['Date'] <= enddate)
        df = df.loc[mask]
    elif startdate == None and enddate == None:
        df = df

    return df

def modify_prodqaqc_ratechokethpvsdate_df(df):
    if not df.empty:

        df['OIL'] = df['OIL'] / df['PROD_DAYS']
        df['M_DATE'] = pd.to_datetime(df['M_DATE'])
        df['OIL'] = df['OIL'].astype(float)
        df['OIL'].fillna(0.0,inplace=True)
        df['BEAN'].fillna(0.0,inplace=True)
        df['THP'].fillna(0.0,inplace=True)

    return df

def modify_prodqaqc_rategorwcvsdate_df(df):
    if not df.empty:

        df['GOR'] = df['GAS']/df['OIL']
        df['WC'] = df['WATER']/(df['OIL']+df['WATER'])
        df['OIL'] = df['OIL'] / df['PROD_DAYS']
        df['M_DATE'] = pd.to_datetime(df['M_DATE'])
        df['OIL'] = df['OIL'].astype(float)
        df['OIL'].fillna(0.0,inplace=True)
        df['GOR'] = df['GOR'].astype(float)
        df['GOR'].fillna(0.0,inplace=True)
        df['WC'] = df['WC'].astype(float)
        df['WC'].fillna(0.0,inplace=True)

    return df

def modify_prodqaqcwelltestdata_datavalidation_prod_df(df_prod):
    if not df_prod.empty:

        df_prod['GOR'] = df_prod['GAS']/df_prod['OIL']
        df_prod['WC'] = df_prod['WATER']/(df_prod['OIL']+df_prod['WATER'])
        df_prod['OIL'] = df_prod['OIL'] / df_prod['PROD_DAYS']
        df_prod['M_DATE'] = pd.to_datetime(df_prod['M_DATE'])
        df_prod['OIL'] = df_prod['OIL'].astype(float)
        df_prod['OIL'].fillna(0.0,inplace=True)
        df_prod['GOR'] = df_prod['GOR'].astype(float)
        df_prod['GOR'].fillna(0.0,inplace=True)
        df_prod['WC'] = df_prod['WC'].astype(float)
        df_prod['WC'].fillna(0.0,inplace=True)

    return df_prod

def modify_prodqaqcwelltestdata_datavalidation_well_df(df_well):
    if not df_well.empty:

        df_well['GOR'] = df_well['GAS']/df_well['OIL']
        df_well['WC'] = df_well['BSW']/100
        df_well['TEST_DATE'] = pd.to_datetime(df_well['TEST_DATE'])
        df_well['OIL'] = df_well['OIL'].astype(float)
        df_well['OIL'].fillna(0.0,inplace=True)
        df_well['GOR'] = df_well['GOR'].astype(float)
        df_well['GOR'].fillna(0.0,inplace=True)
        df_well['WC'] = df_well['WC'].astype(float)
        df_well['WC'].fillna(0.0,inplace=True)

    return df_well
