INTEGRATED_OUTPUT_CSV = "integrated_output.csv"
INTEGRATED_OUTPUT_FULL_CSV = "integrated_output_full.csv"

P_CASE_WELL_LEVEL_ALLCASES = ['P05', 'P10', 'P15', 'P25', 'P40', 'P50', 'P60', 'P75', 'P85', 'P90', 'P95']

COLOR_MAPPING_DICT = {
                        "P05": "#fa8072",
                        "P10": "#8D42E1",
                        "P15": "#ccac00",
                        "P25": "#9acd32",
                        "P40": "#e07719",
                        "P50": "#4CCF2F",
                        "P60": "#00ffff",
                        "P75": "#7a49a5",
                        "P85": "#d59890",
                        "P90": "#FA1C0E",
                        "P95": "#a3ffb4",
                        "Benchmark_forecast-Oil_1P": "#ffdfba",
                        "Benchmark_forecast-Oil_2P": "#ffffba",
                        "Benchmark_forecast-Oil_3P": "#ffb3ba",
                        "History": "#080808",
                        "Decline_Period": "#6c1e2e",
                        "Used_Outlier": "#ff0000",
                        "Selected_Outlier": "#ff69B4",
                        "Allocated_Oil_Rate" : "FF0000",
                        "Allocated_Gas_Rate" : "FF0000",
                        "THP" : "0000FF",
                        "Choke" : "#00FF00",
                        "Oil" : "#FF0000",
                        "Wc" : "#00FF00",
                        "Gor" : "#00FF00"
                        }


UNIQUEWELL = {
    'ratevsdate':{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Date',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'Rate',
        'y2_axis_dfcol': 'Decline_Period',
        'x_axis_title' : 'Date',
        'y_axis_title' : 'Rate',
        'y2_axis_title' : 'Decline-Period',

        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative', 'Decline_Period'],
        'PCase_well_filter' : ['P10','P50','P90']
    },
    'ratevscum' :{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Cum',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'Rate',
        'y2_axis_dfcol': 'Decline_Period',
        'x_axis_title': 'Cum',
        'y_axis_title': 'Rate',
        'y2_axis_title' : 'Decline-Period',

        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative', 'Decline_Period'],
        'PCase_well_filter' : ['P10','P50','P90']
    },
    'divscasewelllevel':{
        'legend_title' : 'Well Cases',
        'title': 'Di vs Case Well Level',
        'x_axis_dfcol' : 'Case_well_level',
        'y_axis_dfcol' : 'Di',
        'x_axis_title': 'Case Well Level',
        'y_axis_title': 'Di(%)',

        'use_colunms': ['Case_well_level', 'Date', 'UNIQUEID', 'Di'],
        'PCase_well_filter' : ['P10','P50','P90']
    },
    
    'bparametervscasewelllevel':{
        'legend_title' : 'Well Cases',
        'title': 'B-Parameter vs Case Well Level',
        'x_axis_dfcol' : 'Case_well_level',
        'y_axis_dfcol' : 'b',
        'x_axis_title': 'Case Well Level',
        'y_axis_title': 'B',

        'use_colunms': ['Case_well_level', 'Date', 'UNIQUEID', 'b'],
        'PCase_well_filter' : ['P10','P50','P90']
    },

    'totalproductionvscasewelllevel':{
        'legend_title' : 'Well Cases',
        'title': 'Total Production vs Case Well Level',
        'x_axis_dfcol' : 'Case_well_level',
        'y_axis_dfcol' : 'Cumulative',
        'x_axis_title': 'Case Well Level',
        'y_axis_title': 'Cumulative Rev',

        'use_colunms': ['Case_well_level', 'Date', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90'],
    },

    'use_colunms_outlier_history' : ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
}

MULTIPLEWELL = {
    'multipleratevsdate' : {
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Date',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'Rate',
        'x_axis_title': 'Date',
        'y_axis_title': 'Rate',

        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID'],
        'PCase_well_filter' : ['P10','P50','P90'],
    },

    'multipleratevscum' : {
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Cumulative Volume',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'Rate',
        'x_axis_title': 'Cumulative Volume',
        'y_axis_title': 'Rate',

        'use_colunms': ['Case_well_level', 'Date', 'Cumulative', 'Rate', 'UNIQUEID'],
        'PCase_well_filter' : ['P10','P50','P90'],
    },

    'multipletotalproductionvscasewelllevel' : {
        'legend_title' : 'Well Cases',
        'title': 'Total Production vs Case Well Level',
        'x_axis_dfcol' : 'Case_well_level',
        'y_axis_dfcol' : 'Cumulative',
        'x_axis_title': 'Case Well Level',
        'y_axis_title': 'Cumulative Rev',

        'use_colunms': ['Case_well_level', 'Date', 'Cumulative', 'Rate', 'UNIQUEID'],
        'PCase_well_filter' : ['P10','P50','P90'],
    },

}

FORECASTVOLUMNES = {
    'forecastvolumestotalprodvsuniqueid' : {
        'legend_title' : 'Well Cases',
        'title': 'Total Production vs UniqueID',
        'x_axis_title': 'Total Production',
        'y_axis_title': 'Unique ID',

        'use_colunms': ['Case_well_level', 'Date', 'Cumulative', 'Rate', 'UNIQUEID'],
        'PCase_well_filter' : ['P10','P50','P90'],
        },
}

PRODQAQC = {

    'prodqaqcratechokethpvsdate' : {
        'legend_title' : 'Prodqaaqc Paramters',
        'title': 'Allocated Oil Rate/Choke/THP vs Date',
        'x_axis_dfcol' : 'M_DATE',
        'y_axis_dfcol' : 'OIL',
        'y2_axis_dfcol' : 'THP',
        'y3_axis_dfcol' : 'Choke',
        'x_axis_title'  : 'Date',
        'y_axis_title_oil'  : 'Allocated Oil Rate',
        'y_axis_title_gas'  : 'Allocated Oil Gas',
        'y2_axis_title' : 'Tubing Head Pressue',
        'y3_axis_title' : 'Choke'
    },

    'prodqaqcrategorwcvsdate' : {
        'legend_title' : 'Prodqaaqc Paramters',
        'title': 'Allocated Oil Rate/GOR/WC vs Date',
        'x_axis_dfcol' : 'M_DATE',
        'y_axis_dfcol' : 'OIL',
        'y2_axis_dfcol' : 'WC',
        'y3_axis_dfcol' : 'GOR',
        'x_axis_title'  : 'Date',
        'y_axis_title'  : 'Allocated Oil Rate',
        'y2_axis_title' : 'Water Cut',
        'y3_axis_title' : 'GOR'
    }

}

PRODQAQCWELLTESTDATA = {

    'prodqaqcwelltestdatadatavalidation' : {
        'legend_title' : 'Prodqaaqcwelltestdata Paramters',
        'title': 'Production History QA-QC: Validation with well test data',
        'x_axis_dfcol' : 'M_DATE',
        'y_axis_dfcol' : 'OIL',
        'y2_axis_dfcol' : 'THP',
        'y3_axis_dfcol' : 'Choke',
        'x_axis_title'  : 'Date',
        'y_axis_title_oil'  : 'Allocated Oil Rate',
        'y_axis_title_gas'  : 'Allocated Oil Gas',
        'y2_axis_title' : 'Tubing Head Pressue',
        'y3_axis_title' : 'Choke'
    },

}

