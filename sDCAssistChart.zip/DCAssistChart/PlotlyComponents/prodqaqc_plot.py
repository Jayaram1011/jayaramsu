from DCAssistChart.dbqueries import get_prodqaqc_ratechokethpvsdate_data, get_prodqaqc_rategorwcvsdate_data
from DCAssistChart.PlotlyComponents.utils.ploty_constant import PRODQAQC
from DCAssistChart.PlotlyComponents.utils.df_queries import create_df, modify_prodqaqc_ratechokethpvsdate_df, modify_prodqaqc_rategorwcvsdate_df
from DCAssistChart.PlotlyComponents.plot_figures.prodqaqc_plot_figure import prodqaqc_ratechokethpvsdate_plot_figure, get_data_not_found_fig, prodqaqc_rategorwcvsdate_plot_figure

def prodqaqc_ratechokethpvsdate(dropdown_value, prodqaqc_data):
    if dropdown_value in prodqaqc_data['uniqueids']:
        prodqaqc_ratechokethpvsdate_data = get_prodqaqc_ratechokethpvsdate_data(assetdb = prodqaqc_data['assetdb'], uniqueid = prodqaqc_data['uniqueids'])
        
        df = create_df(list(prodqaqc_ratechokethpvsdate_data))

        df = modify_prodqaqc_ratechokethpvsdate_df(df)

        fig = prodqaqc_ratechokethpvsdate_plot_figure(df, prodqaqc_data = prodqaqc_data, units = prodqaqc_data['units'], plot_name='prodqaqcratechokethpvsdate')

        return fig

    else:
        return get_data_not_found_fig(title= PRODQAQC['prodqaqcratechokethpvsdate']['title'])
        

def prodqaqc_rategorwcvsdate(dropdown_value, prodqaqc_data):
    if dropdown_value in prodqaqc_data['uniqueids']:
        prodqaqc_rategorwcvsdate_data = get_prodqaqc_rategorwcvsdate_data(assetdb = prodqaqc_data['assetdb'], uniqueid = prodqaqc_data['uniqueids'])
        
        df = create_df(list(prodqaqc_rategorwcvsdate_data))

        df = modify_prodqaqc_rategorwcvsdate_df(df)

        fig = prodqaqc_rategorwcvsdate_plot_figure(df, prodqaqc_data = prodqaqc_data, units = prodqaqc_data['units'], plot_name='prodqaqcrategorwcvsdate')

        return fig

    else:
        return get_data_not_found_fig(title= PRODQAQC['prodqaqcrategorwcvsdate']['title'])