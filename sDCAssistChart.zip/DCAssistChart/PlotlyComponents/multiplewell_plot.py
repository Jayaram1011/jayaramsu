from runalgorithm.helper import get_run_dir
from DCAssistChart.PlotlyComponents.utils.ploty_constant import INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV, P_CASE_WELL_LEVEL_ALLCASES, MULTIPLEWELL
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.df_queries import get_integrated_output_df, rename_columncontent_df, list_unique_string_in_col, get_filtered_df_multiple_dropdown, empty_df, groupbysum_df, dropna_df, sort_df, dict_to_df, start_to_end_dates_df
from DCAssistChart.PlotlyComponents.plot_figures.multiplewell_plot_figure import multiplewell_datecumvsrate_plot_figure, get_data_not_found_fig, multiplewell_totalproductionvscasewelllevel_plot_figure

def multiplewell_ratevsdate(dropdown_value, multiplewell_data):
    if dropdown_value != None:

        df = empty_df()

        for uniqueid_dropdown_value in dropdown_value:
            runid, well_type = multiplewell_data['uniqueids'][uniqueid_dropdown_value].split(',')   

            file_name = INTEGRATED_OUTPUT_CSV

            if multiplewell_data["allcases"] == True:
                file_name = INTEGRATED_OUTPUT_FULL_CSV

            path = get_run_dir(multiplewell_data['assetdb'], runid)
            integrated_output_path = get_file_path(path,file_name)
            
            df_dropdownvalue = get_integrated_output_df(integrated_output_path, MULTIPLEWELL['multipleratevsdate']['use_colunms'])
            df_dropdownvalue = rename_columncontent_df(df_dropdownvalue)

            if not df_dropdownvalue.empty:
                df = df.append(df_dropdownvalue)
            else:
                continue
       
        df = dropna_df(df, col_name = 'Rate')
        df = groupbysum_df(df, col_list = ['Date', 'Case_well_level'])
        
        p_case_well_levels_list = MULTIPLEWELL['multipleratevsdate']['PCase_well_filter']
        if multiplewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        benchmark_case_well_levels_list = list_unique_string_in_col(df, col_name = "Case_well_level", string_startwith = "Benchmark")

        df_p_case_well_levels_list = []
        df_benchmark_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list): 
            df_p_case_well_levels = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [p_case_well_levels_list[index]])
            df_p_case_well_levels_list.append(df_p_case_well_levels)

        for index, value in enumerate(benchmark_case_well_levels_list): 
            df_benchmark_case_well_levels = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [benchmark_case_well_levels_list[index]])
            df_benchmark_case_well_levels_list.append(df_benchmark_case_well_levels)

        df_history = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = ['History'])     

        fig = multiplewell_datecumvsrate_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, df_history, units = multiplewell_data['units'], plot_name='multipleratevsdate')

        return fig

    else:
        return get_data_not_found_fig(title= MULTIPLEWELL['multipleratevsdate']['title'])

def multiplewell_ratevscum(dropdown_value, multiplewell_data):

    if dropdown_value != None:

        df = empty_df()

        for uniqueid_dropdown_value in dropdown_value:
            runid, well_type = multiplewell_data['uniqueids'][uniqueid_dropdown_value].split(',')   

            file_name = INTEGRATED_OUTPUT_CSV

            if multiplewell_data["allcases"] == True:
                file_name = INTEGRATED_OUTPUT_FULL_CSV

            path = get_run_dir(multiplewell_data['assetdb'], runid)
            integrated_output_path = get_file_path(path,file_name)
            
            df_dropdownvalue = get_integrated_output_df(integrated_output_path, MULTIPLEWELL['multipleratevscum']['use_colunms'])

            df_dropdownvalue = rename_columncontent_df(df_dropdownvalue)

            if not df_dropdownvalue.empty:
                df = df.append(df_dropdownvalue)
            else:
                continue
       
        df = dropna_df(df, col_name = 'Rate')
        df = groupbysum_df(df, col_list = ['Date', 'Case_well_level'])

        p_case_well_levels_list = MULTIPLEWELL['multipleratevscum']['PCase_well_filter']
        if multiplewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        benchmark_case_well_levels_list = list_unique_string_in_col(df, col_name = "Case_well_level", string_startwith = "Benchmark")

        df_p_case_well_levels_list = []
        df_benchmark_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list): 
            df_p_case_well_levels = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [p_case_well_levels_list[index]])
            df_p_case_well_levels_list.append(df_p_case_well_levels)

        for index, value in enumerate(benchmark_case_well_levels_list): 
            df_benchmark_case_well_levels = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [benchmark_case_well_levels_list[index]])
            df_benchmark_case_well_levels_list.append(df_benchmark_case_well_levels)

        df_history = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = ['History'])     

        fig = multiplewell_datecumvsrate_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, df_history, units = multiplewell_data['units'], plot_name='multipleratevscum')

        return fig

    else:
        return get_data_not_found_fig(title= MULTIPLEWELL['multipleratevsdate']['title'])

def multiplewell_totalproductionvscasewelllevel(dropdown_value, multiplewell_data, startdate, enddate):

    if dropdown_value != None:

        df = empty_df()

        for uniqueid_dropdown_value in dropdown_value:
            runid, well_type = multiplewell_data['uniqueids'][uniqueid_dropdown_value].split(',')         

            file_name = INTEGRATED_OUTPUT_CSV

            if multiplewell_data["allcases"] == True:
                file_name = INTEGRATED_OUTPUT_FULL_CSV

            path = get_run_dir(multiplewell_data['assetdb'], runid)
            integrated_output_path = get_file_path(path,file_name)
            
            df_dropdownvalue = get_integrated_output_df(integrated_output_path, MULTIPLEWELL['multipletotalproductionvscasewelllevel']['use_colunms'])

            df_dropdownvalue = rename_columncontent_df(df_dropdownvalue)

            df_dropdownvalue = start_to_end_dates_df(df_dropdownvalue, startdate, enddate)

            if not df_dropdownvalue.empty:
                df = df.append(df_dropdownvalue)
            else:
                continue

        df = dropna_df(df, col_name = 'Cumulative')

        p_case_well_levels_list = MULTIPLEWELL['multipletotalproductionvscasewelllevel']['PCase_well_filter']
        if multiplewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        benchmark_case_well_levels_list = list_unique_string_in_col(df, col_name = "Case_well_level", string_startwith = "Benchmark")

        df_p_case_well_levels_list = []
        df_benchmark_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            p_case_well_levels_filter_df = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [p_case_well_levels_list[index]])
            p_case_well_levels_filter_df = sort_df(p_case_well_levels_filter_df, ['Date'])

            temp_dict = {'UNIQUEID':[],'Cumulative':[],'Case_well_level':[]}
            for uniqueid_dropdown_value in dropdown_value:
                p_case_and_uniqueid_filter_df = get_filtered_df_multiple_dropdown(p_case_well_levels_filter_df, col_name = 'UNIQUEID', _filters = [uniqueid_dropdown_value])
                p_case_and_uniqueid_filter_df = sort_df(p_case_and_uniqueid_filter_df, ['Date'])
                temp_dict['UNIQUEID'].append(uniqueid_dropdown_value)
                temp_dict['Cumulative'].append(float(p_case_and_uniqueid_filter_df.tail(1).Cumulative.values - p_case_and_uniqueid_filter_df.head(1).Cumulative.values))
                temp_dict['Case_well_level'].append(value)

            temp_dict_df = dict_to_df(dict_name = temp_dict)  
            df_p_case_well_levels_sum = groupbysum_df(temp_dict_df, col_list = ['Case_well_level'])

            df_p_case_well_levels_list.append(df_p_case_well_levels_sum)

        for index, value in enumerate(benchmark_case_well_levels_list):
            benchmark_case_well_levels_filter_df = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [benchmark_case_well_levels_list[index]])
            benchmark_case_well_levels_filter_df = sort_df(benchmark_case_well_levels_filter_df, ['Date'])

            temp_dict = {'UNIQUEID':[],'Cumulative':[],'Case_well_level':[]}
            for uniqueid_dropdown_value in dropdown_value:
                benchmark_case_and_uniqueid_filter_df = get_filtered_df_multiple_dropdown(benchmark_case_well_levels_filter_df, col_name = 'UNIQUEID', _filters = [uniqueid_dropdown_value])
                benchmark_case_and_uniqueid_filter_df = sort_df(benchmark_case_and_uniqueid_filter_df, ['Date'])
                temp_dict['UNIQUEID'].append(uniqueid_dropdown_value)
                temp_dict['Cumulative'].append(float(benchmark_case_and_uniqueid_filter_df.tail(1).Cumulative.values - benchmark_case_and_uniqueid_filter_df.head(1).Cumulative.values))
                temp_dict['Case_well_level'].append(value)

            temp_dict_df = dict_to_df(dict_name = temp_dict)  
            df_benchmark_case_well_levels_sum = groupbysum_df(temp_dict_df, col_list = ['Case_well_level'])

            df_benchmark_case_well_levels_list.append(df_benchmark_case_well_levels_sum)      
        
        fig = multiplewell_totalproductionvscasewelllevel_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, units = multiplewell_data['units'], plot_name='multipletotalproductionvscasewelllevel')
        
        return fig
    else:
        return get_data_not_found_fig(title= MULTIPLEWELL['multipleratevsdate']['title'])
