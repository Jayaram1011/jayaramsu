from runalgorithm.helper import get_run_dir
from DCAssistChart.PlotlyComponents.utils.ploty_constant import INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV, UNIQUEWELL, P_CASE_WELL_LEVEL_ALLCASES
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.df_queries import get_integrated_output_df, rename_columncontent_df, get_filtered_df, get_outlier_history_df, empty_df,di_calc_update, b_calc_update, dropna_df, list_unique_string_in_col, get_filtered_df_multiple_dropdown, sort_df, dict_to_df
from DCAssistChart.PlotlyComponents.plot_figures.uniquewell_plot_figure import uniquewell_plot_figure, get_data_not_found_fig, uniquewell_di_and_b_plot_figure, uniquewell_totalproductionvscasewelllevel_plot_figure

def uniquewell_ratevsdate(dropdown_value,uniquewell_data,outlier_data):

    if dropdown_value in uniquewell_data['uniqueids']:
        runid, well_type = uniquewell_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if uniquewell_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(uniquewell_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, UNIQUEWELL['ratevsdate']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = UNIQUEWELL['ratevsdate']['PCase_well_filter']
        if uniquewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)

        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
        df_decline_period = df[[UNIQUEWELL['ratevsdate']['x_axis_dfcol'], UNIQUEWELL['ratevsdate']['y2_axis_dfcol']]]

        outlier_history_path = get_file_path(path, "Outlier_History_Data.csv")
        df_outlier_history = get_outlier_history_df(outlier_history_path, UNIQUEWELL['use_colunms_outlier_history'])

        df_selected_outlier = empty_df()
        if dropdown_value in outlier_data and not uniquewell_data['system']:
            db_dates = outlier_data[dropdown_value]
            dates = db_dates

            if not df_outlier_history.empty:
                file_dates = df_outlier_history['Date'].to_list()
                file_dates = [str(date.to_pydatetime()).split()[0] for date in file_dates]
                dates = [date for date in db_dates if date not in file_dates]

            if dates:
                df_selected_outlier = df_history.loc[df_history['Date'].isin(dates)]
        
        fig = uniquewell_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, df_history,df_decline_period,well_type, df_selected_outlier, df_used_outlier = df_outlier_history, units = uniquewell_data['units'], plot_name = 'ratevsdate')
        return fig
        
    else:
        return get_data_not_found_fig(title= UNIQUEWELL['ratevsdate']['title'])

def uniquewell_ratevscum(dropdown_value,uniquewell_data):

    if dropdown_value in uniquewell_data['uniqueids']:
        runid, well_type = uniquewell_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if uniquewell_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(uniquewell_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, UNIQUEWELL['ratevscum']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = UNIQUEWELL['ratevscum']['PCase_well_filter']
        if uniquewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)

        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])

        df_decline_period = df[[UNIQUEWELL['ratevscum']['x_axis_dfcol'], UNIQUEWELL['ratevscum']['y2_axis_dfcol']]]

        df_selected_outlier = empty_df()
        df_outlier_history = empty_df()

        fig = uniquewell_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,df_history,df_decline_period,well_type, df_selected_outlier, df_used_outlier = df_outlier_history, units = uniquewell_data['units'], plot_name = 'ratevscum')
        return fig
        
    else:
        return get_data_not_found_fig(title= UNIQUEWELL['ratevsdate']['title'])

def uniquewell_divscasewelllevel(dropdown_value,uniquewell_data):

    if dropdown_value in uniquewell_data['uniqueids']:
        runid, well_type = uniquewell_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if uniquewell_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(uniquewell_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, UNIQUEWELL['divscasewelllevel']['use_colunms'])
        df = rename_columncontent_df(df)
        df = di_calc_update(df)

        p_case_well_levels_list = UNIQUEWELL['divscasewelllevel']['PCase_well_filter']
        if uniquewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)

        fig = uniquewell_di_and_b_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, plot_name='divscasewelllevel')

        return fig

    else:
        return get_data_not_found_fig(title= UNIQUEWELL['divscasewelllevel']['title'])

def uniquewell_bparametervscasewelllevel(dropdown_value,uniquewell_data):
    if dropdown_value in uniquewell_data['uniqueids']:
        runid, well_type = uniquewell_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV

        if uniquewell_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(uniquewell_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, UNIQUEWELL['bparametervscasewelllevel']['use_colunms'])

        df = rename_columncontent_df(df)
        df = b_calc_update(df)

        p_case_well_levels_list = UNIQUEWELL['bparametervscasewelllevel']['PCase_well_filter']
        if uniquewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)

        fig = uniquewell_di_and_b_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, plot_name='bparametervscasewelllevel')

        return fig

    else:
        return get_data_not_found_fig(title= UNIQUEWELL['bparametervscasewelllevel']['title'])

def uniquewell_totalproductionvscasewelllevel(dropdown_value,uniquewell_data):

    if dropdown_value in uniquewell_data['uniqueids']:
        runid, well_type = uniquewell_data['uniqueids'][dropdown_value].split(',')

        file_name = INTEGRATED_OUTPUT_CSV

        if uniquewell_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(uniquewell_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
            
        df = get_integrated_output_df(integrated_output_path, UNIQUEWELL['totalproductionvscasewelllevel']['use_colunms'])

        df = rename_columncontent_df(df)

        df = dropna_df(df, col_name = 'Cumulative')

        p_case_well_levels_list = UNIQUEWELL['totalproductionvscasewelllevel']['PCase_well_filter']
        if uniquewell_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        benchmark_case_well_levels_list = list_unique_string_in_col(df, col_name = "Case_well_level", string_startwith = "Benchmark")

        df_p_case_well_levels_list = []
        df_benchmark_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            p_case_well_levels_filter_df = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [p_case_well_levels_list[index]])
            p_case_well_levels_filter_df = sort_df(p_case_well_levels_filter_df, ['Date'])

            p_case_and_uniqueid_filter_df = get_filtered_df_multiple_dropdown(p_case_well_levels_filter_df, col_name = 'UNIQUEID', _filters = [dropdown_value])
            p_case_and_uniqueid_filter_df = sort_df(p_case_and_uniqueid_filter_df, ['Date'])

            temp_dict = {'UNIQUEID':[],'Cumulative':[],'Case_well_level':[]}
            temp_dict['UNIQUEID'].append(dropdown_value)
            temp_dict['Cumulative'].append(float(p_case_and_uniqueid_filter_df.tail(1).Cumulative.values - p_case_and_uniqueid_filter_df.head(1).Cumulative.values))
            temp_dict['Case_well_level'].append(value)

            cumulative_total_p_case_df = dict_to_df(dict_name = temp_dict)  

            df_p_case_well_levels_list.append(cumulative_total_p_case_df)

        for index, value in enumerate(benchmark_case_well_levels_list):
            benchmark_case_well_levels_filter_df = get_filtered_df_multiple_dropdown(df, col_name = 'Case_well_level', _filters = [benchmark_case_well_levels_list[index]])
            benchmark_case_well_levels_filter_df = sort_df(benchmark_case_well_levels_filter_df, ['Date'])

            benchmark_case_and_uniqueid_filter_df = get_filtered_df_multiple_dropdown(benchmark_case_well_levels_filter_df, col_name = 'UNIQUEID', _filters = [dropdown_value])
            benchmark_case_and_uniqueid_filter_df = sort_df(benchmark_case_and_uniqueid_filter_df, ['Date'])

            temp_dict = {'UNIQUEID':[],'Cumulative':[],'Case_well_level':[]}
            temp_dict['UNIQUEID'].append(dropdown_value)
            temp_dict['Cumulative'].append(float(benchmark_case_and_uniqueid_filter_df.tail(1).Cumulative.values - benchmark_case_and_uniqueid_filter_df.head(1).Cumulative.values))
            temp_dict['Case_well_level'].append(value)

            cumulative_total_benchmark_case_df = dict_to_df(dict_name = temp_dict)  

            df_benchmark_case_well_levels_list.append(cumulative_total_benchmark_case_df)
        
        fig = uniquewell_totalproductionvscasewelllevel_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list, benchmark_case_well_levels_list, df_benchmark_case_well_levels_list, units = uniquewell_data['units'], plot_name='totalproductionvscasewelllevel')
        
        return fig
    else:
        return get_data_not_found_fig(title= UNIQUEWELL['totalproductionvscasewelllevel']['title'])





    