from django.shortcuts import render

# Create your views here.

def get_user_assetdb(request):
    userid = request.dcauser
    assetdb = request.assetdb
    return userid, assetdb

def get_user_assetdb_system(request):
    userid, assetdb = get_user_assetdb(request)
    system = request.GET.get('system')
    return userid, assetdb, system

def forecastmultiplewells_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context

    return render(request, 'DCAssistChart/multiplewell.html')

def forecastmultiplewellsallwells_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context

    return render(request, 'DCAssistChart/multiplewell.html')

def forecastuniquewellratevsdate_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellratevsdate.html')
    
def forecastuniquewellallwellsratevsdate_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellratevsdate.html')


def forecastuniquewellratevscum_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellratevscum.html')
    
def forecastuniquewellallwellsratevscum_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellratevscum.html')

def forecastuniquewellratevscum_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellratevscum.html')
    
def forecastuniquewellallwellsratevscum_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellratevscum.html')

def forecastuniquewelldivscasewelllevel_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewelldivscasewelllevel.html')

def forecastuniquewellallwellsdivscasewelllevel_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewelldivscasewelllevel.html')

def forecastuniquewellbparametervscasewelllevel_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellbparametervscasewelllevel.html')

def forecastuniquewellallwellsbparametervscasewelllevel_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewellbparametervscasewelllevel.html')

def forecastuniquewell_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewell.html')

def forecastuniquewellallwells_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewell.html')

def forecastvolumes_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': False}
    session['django_plotly_dash'] = context

    return render(request, 'DCAssistChart/forecastvolumes.html')

def forecastvolumesallwells_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, 'allcases': True}
    session['django_plotly_dash'] = context

    return render(request, 'DCAssistChart/forecastvolumes.html')

def prodqaqc_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, "failed":True}
    session['django_plotly_dash'] = context

    return render(request, 'DCAssistChart/prodqaqc.html')


def prodqaqcwelltestdata_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)

    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system, "failed":True}
    session['django_plotly_dash'] = context

    return render(request, 'DCAssistChart/prodqaqcwelltestdata.html')
