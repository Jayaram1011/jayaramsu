from dash import html, dcc, ctx
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

import dash_bootstrap_components as dbc
import dash

from DCAssistChart.DashComponents.utils import get_uniquewell_data
from DCAssistChart.PlotlyComponents.uniquewell_plot import uniquewell_bparametervscasewelllevel

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_uniquewellbparametervscasewelllevel= DjangoDash("uniquewellbparametervscasewelllevel", add_bootstrap_links=True)

app_uniquewellbparametervscasewelllevel.layout = html.Div([

                                        dbc.Col([
                                            html.Br(),
                                            html.H5('Unique ID'),
                                        ], style={'textAlign': 'center'}),

                                        html.Br(),  

                                        dcc.Store(id='uniquewell_data_id', storage_type='memory'),

                                        dbc.Col([
                                            dcc.Dropdown(id='uniquewell_dropdown_id',
                                                    options=[],
                                                    placeholder="Select Uniqwell",
                                                    style={'fontSize': "15px", 'textAlign': 'center'}),
                                            ], lg=8, className ="mw-100"), 

                                        html.Br(),

                                        dbc.Col([
                                        html.P('This plot window shows forecast rates and forecast parameter values for different forecast cases for selected wells.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
                                        html.P('Enlarge the Rate vs Date and Rate vs Cumulative Volume to see comparison with the benchmark case.',style={'fontSize': "17px", 'textAlign': 'center','background-color': '#FFFF00'}),
                                        ],className ="mw-100 text-info"),

                                        html.Br(),

                                        dbc.Col([
                                                dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                                                ],className ="mw-100"),

                                        html.Br(),
                                        dbc.Col([
                                            dcc.Loading(
                                            id="loading_1",
                                            type="circle",
                                            children= [dcc.Graph(id='uniquewell_bparametervscasewelllevel', config=config, style={'width': '100%','display': 'inline-block'})],
                                            )
                                        ]),

                                    ],className="container-fluid")


@app_uniquewellbparametervscasewelllevel.callback(
    Output('uniquewell_dropdown_id','options'),Output('uniquewell_data_id','data'),Output('allcases_link_id', 'href'),
    Input('uniquewell_data_id','data')
)
def dropdown_options(data, session_state=None):
    uniquewell_data = get_uniquewell_data(session_state['userid'], session_state['assetdb'], session_state['system'],session_state['allcases'])

    if len(uniquewell_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in uniquewell_data.get('uniqueids').keys()]
    else:
        options = []

    if uniquewell_data['system'] == 'true':
        return options,uniquewell_data,f'/chart/forecastuniquewellallwellsbparametervscasewelllevel/?userId={uniquewell_data["userid"]}&system=true'
    else:
        return options,uniquewell_data,f'/chart/forecastuniquewellallwellsbparametervscasewelllevel/?userId={uniquewell_data["userid"]}' 

# pylint: ignore=unused-argument
@app_uniquewellbparametervscasewelllevel.callback(
    Output(component_id='uniquewell_bparametervscasewelllevel', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    )
def plot_bparametervscasewelllevel(value, uniquewell_data):
    return uniquewell_bparametervscasewelllevel(dropdown_value=value,uniquewell_data=uniquewell_data)
