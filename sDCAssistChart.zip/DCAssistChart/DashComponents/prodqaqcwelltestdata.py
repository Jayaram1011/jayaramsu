from dash import html, dcc, ctx
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

import dash_bootstrap_components as dbc
import dash

from DCAssistChart.DashComponents.utils import get_prodqaqcwelltestdata_data
from DCAssistChart.PlotlyComponents.prodqaqcwelltestdata_plot import prodqaqcwelltestdata_datavalidation

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_prodqaqcwelltestdata = DjangoDash("prodqaqcwelltestdata", add_bootstrap_links=True)

app_prodqaqcwelltestdata.layout = html.Div([

                                dbc.Col([
                                    html.Br(),
                                    html.H5('Unique ID'),
                                ], style={'textAlign': 'center'}),

                                html.Br(),  

                                dcc.Store(id='prodqaqcwelltestdata_data_id', storage_type='memory'),

                                dbc.Col([
                                    dcc.Dropdown(id='prodqaqcwelltestdata_dropdown_id',
                                    options=[],
                                    placeholder="Select Uniqwell",
                                    style={'fontSize': "15px", 'textAlign': 'center'}),
                                    ], lg=8, className ="mw-100"), 

                                html.Br(),

                                dbc.Col([
                                    html.P('This plot window displays allocated rates and phase ratios along with the corresponding well test values. Applicable only if well test data is provided as input.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
                                ],className ="mw-100 text-info"),

                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_1",
                                    type="circle",
                                    children= [dcc.Graph(id='prodqaqcwelltestdata_datavalidation', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),

                            ])

@app_prodqaqcwelltestdata.callback(
    Output('prodqaqcwelltestdata_dropdown_id','options'),Output('prodqaqcwelltestdata_dropdown_id','value'),Output('prodqaqcwelltestdata_data_id','data'),
    Input('prodqaqcwelltestdata_data_id','data')
)
def dropdown_options(data, session_state=None):
    prodqaqcwelltestdata_data = get_prodqaqcwelltestdata_data(session_state['userid'], session_state['assetdb'], session_state['system'], session_state['failed'])

    if len(prodqaqcwelltestdata_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in prodqaqcwelltestdata_data.get('uniqueids').keys()]
        selected_dropdown_value = sorted(list(prodqaqcwelltestdata_data.get('uniqueids').keys()))[0]

    else:
        options = []
        selected_dropdown_value = ''

    return options,selected_dropdown_value,prodqaqcwelltestdata_data


# pylint: ignore=unused-argument
@app_prodqaqcwelltestdata.callback(
    Output(component_id='prodqaqcwelltestdata_datavalidation', component_property='figure'),
    [Input('prodqaqcwelltestdata_dropdown_id', 'value'), Input('prodqaqcwelltestdata_data_id', 'data')],
    )
def plot_prodqaqcrategorwcvsdate(value, prodqaqcwelltestdata_data):
    return prodqaqcwelltestdata_datavalidation(dropdown_value=value,prodqaqcwelltestdata_data=prodqaqcwelltestdata_data)