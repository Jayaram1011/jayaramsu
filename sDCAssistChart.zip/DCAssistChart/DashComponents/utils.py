from DCAssistChart.dbqueries import get_units, get_cluster
from DCAssist.settings import DOMAIN_NAME
from datetime import datetime

from auditlog.helper import start_audit_log, end_audit_log
from DCAssistChart.dbconnection import DBConnection, delete_outlier_records_data, update_selected_outlier_for_next_runanalysis_data, update_startdate_enddate_decline_period_data

from runalgorithm.helper import get_run_dir
from DCAssistChart.PlotlyComponents.utils.ploty_constant import INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV, P_CASE_WELL_LEVEL_ALLCASES, FORECASTVOLUMNES
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.df_queries import get_integrated_output_df, list_unique_string_in_col 

import logging

logger = logging.getLogger(__name__)

# Uniquewellsutils
def get_uniquewell_data(userid, assetdb, system, allcases):
    dbc = DBConnection()
    if system == True:
        uniquewell_data = dbc.activewellsoutputdirwithndsys(assetdb,userid)
    else:
        uniquewell_data = dbc.activewellsoutputdirwithnd(assetdb,userid)
    uniquewell_data['assetdb'] = assetdb
    uniquewell_data['allcases'] = allcases
    uniquewell_data['domain'] = DOMAIN_NAME
    uniquewell_data['system'] = system
    uniquewell_data['units'] = get_units(assetdb)
    # uniquewell_data['outliers'] = dbc.get_outlier_db_data(assetdb, userid) 
    return uniquewell_data

def get_outliers_data(assetdb, userid):
    dbc = DBConnection()
    outlier_data = dbc.get_outlier_db_data(assetdb, userid) 
    return outlier_data

def outlier_format_date(str):
    return datetime.strptime(str,'%Y-%m-%d').strftime("%Y-%m-%d")

def select_box_data(selectedData, value, uniquewell_data, selectedcolumn):
    points = []
    uniquewell_selected_data = {}
    if selectedData:
        dates = []
        if selectedData['points']:
            points = selectedData['points']
            
            uniquewell_selected_data['assetdb'] = uniquewell_data["assetdb"]
            uniquewell_selected_data['user_id'] = uniquewell_data["userid"]
            uniquewell_selected_data['selected_column'] = selectedcolumn
            uniquewell_selected_data['well_id'] = value
        
            for point in points:
                dates.append(point['x'])
            date_list = [outlier_format_date(date) for date in dates]
            uniquewell_selected_data['selected_dates'] = date_list
        return uniquewell_selected_data
    return uniquewell_selected_data

def reset_outlier_data(uniqueid, asset_db, user_id):
    if user_id:
        try:
            audit_id = start_audit_log(asset_db, user_id,[uniqueid], 'resetOutliers')
            logger.info('Calling reset_outlier_data Fuction')
            delete_outlier_records_data(asset_db, user_id, uniqueid)
            end_audit_log(asset_db, audit_id, "success", "Outliers are reset", [uniqueid])
            return "Outlier data was reset!!!"
        except Exception as e:
            end_audit_log(asset_db, audit_id, "failure", str(e), [uniqueid])
            logger.error(e, exc_info=True)
            return "Exception occur while Reset Outiler."
    return "Failed to reset outiler. UserID not present."

def update_selected_outlier_data(uniqueid, asset_db, user_id, selected_date_list, selected_column):
    if user_id:
        try:
            print(selected_date_list)
            audit_id = start_audit_log(asset_db, user_id, [uniqueid], 'removeOutliers')
            delete_outlier_records_data(asset_db, user_id, uniqueid)
            logger.info('Calling exclude_selected_data Fuction')
            update_selected_outlier_for_next_runanalysis_data(asset_db, uniqueid, user_id, selected_column, selected_date_list)            
            end_audit_log(asset_db, audit_id, "success", "Outliers are removed", [uniqueid])
            return "Outliers are Set. Refresh Page to See Outlier Changes !!!"
        except Exception as e:
            end_audit_log(user_id, audit_id, "failure", str(e), [uniqueid])
            logger.error(e, exc_info=True)
            return "Exception occur while updating selected outiler."
    return "Failed to update selected outiler. UserID not present."

def update_selected_dates_decline_period(uniqueid, asset_db, user_id, selected_date_list):
    if user_id:
        try :
            audit_id = start_audit_log(asset_db, user_id, [uniqueid], 'updateDateDeclinePeriod')
            selected_date_list.sort()
            decline_start_date = selected_date_list[0]
            decline_end_date = selected_date_list[-1]
            logger.info('Calling update decline date Function')
            update_startdate_enddate_decline_period_data(decline_start_date, decline_end_date, asset_db, uniqueid, user_id)
            end_audit_log(asset_db, audit_id, "success", "Updated Decline Period Start and End Date", [uniqueid])
            return "Decline Period selected box start and end date updated Successfully."
        except Exception as e:
            end_audit_log(asset_db, audit_id, "failure", str(e), [uniqueid])
            logger.error(e, exc_info=True)
            return "Exception occur while updating decline period start date and end date."
    return "Failed to update decline period. UserID not present."

# Forecastvolumesutils
def get_forecastvolumes_data(userid, assetdb, system, allcases):
    dbc = DBConnection()
    if system == True:
        forecastvolumes_data = dbc.activewellsoutputdirwithndsys(assetdb,userid)
    else:
        forecastvolumes_data = dbc.activewellsoutputdir_with_nd(assetdb,userid)

    forecastvolumes_data['assetdb'] = assetdb
    forecastvolumes_data['allcases'] = allcases
    forecastvolumes_data['domain'] = DOMAIN_NAME
    forecastvolumes_data['system'] = system
    forecastvolumes_data['units'] = get_units(assetdb)
    return forecastvolumes_data


# Multiplewellutils
def get_multiplewell_data(userid, assetdb, system, allcases):
    dbc = DBConnection()
    if system == True:
        multiplewell_data = dbc.activewellsoutputdirwithndsys(assetdb,userid)
    else:
        multiplewell_data = dbc.activewellsoutputdir_with_nd(assetdb,userid)

    multiplewell_data['assetdb'] = assetdb
    multiplewell_data['allcases'] = allcases
    multiplewell_data['domain'] = DOMAIN_NAME
    multiplewell_data['system'] = system
    multiplewell_data['units'] = get_units(assetdb)
    return multiplewell_data

#Prodqaqcutills
def get_prodqaqc_data(userid, assetdb, system, failed):
    dbc = DBConnection()
    if system == True:
        if failed == None:
            prodqaqc_data = dbc.activewellsoutputdirsys(assetdb,userid)
        else:
            prodqaqc_data = dbc.activewellsoutputdirsys(assetdb,userid,failed)
    else:
        if failed == None:
            prodqaqc_data = dbc.activewellsoutputdir(assetdb,userid)
        else:
            prodqaqc_data = dbc.activewellsoutputdir(assetdb,userid,failed)

    prodqaqc_data['assetdb'] = assetdb
    prodqaqc_data['cluster'] = get_cluster(prodqaqc_data, assetdb)
    prodqaqc_data['domain'] = DOMAIN_NAME
    prodqaqc_data['system'] = system
    prodqaqc_data['units'] = get_units(assetdb)
    return prodqaqc_data

#Prodqaqcwelltestdata
def get_prodqaqcwelltestdata_data(userid, assetdb, system, failed):
    dbc = DBConnection()
    if system == True:
        if failed == None:
            prodqaqcwelltestdata_data = dbc.activewellsoutputdirsys(assetdb,userid)
        else:
            prodqaqcwelltestdata_data = dbc.activewellsoutputdirsys(assetdb,userid,failed)
    else:
        if failed == None:
            prodqaqcwelltestdata_data = dbc.activewellsoutputdir(assetdb,userid)
        else:
            prodqaqcwelltestdata_data = dbc.activewellsoutputdir(assetdb,userid,failed)

    prodqaqcwelltestdata_data['assetdb'] = assetdb
    prodqaqcwelltestdata_data['cluster'] = get_cluster(prodqaqcwelltestdata_data, assetdb)
    prodqaqcwelltestdata_data['domain'] = DOMAIN_NAME
    prodqaqcwelltestdata_data['system'] = system
    prodqaqcwelltestdata_data['units'] = get_units(assetdb)
    return prodqaqcwelltestdata_data


def get_benchmark_dropdown_options(data, plot_name_constant_details):

    for uniqueid,path in data.get('uniqueids').items():

        runid, well_type = path.split(',')

        file_name = INTEGRATED_OUTPUT_CSV

        p_case_well_levels_list = eval(plot_name_constant_details + str(['PCase_well_filter']))

        if data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
            
        df = get_integrated_output_df(integrated_output_path, eval(plot_name_constant_details + str(['use_colunms'])))

        benchmark_case_well_levels_list = list_unique_string_in_col(df, col_name = "Case_well_level", string_startwith = "Benchmark")

        case_well_levels_list = p_case_well_levels_list + benchmark_case_well_levels_list

    return case_well_levels_list
