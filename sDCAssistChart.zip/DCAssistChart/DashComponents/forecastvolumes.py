from dash import html, dcc, ctx
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

import dash_bootstrap_components as dbc
import dash

from DCAssistChart.DashComponents.utils import get_forecastvolumes_data, get_benchmark_dropdown_options
from DCAssistChart.PlotlyComponents.forecastvolumes_plot import forecastvolumes_totalprodvsuniqueid
from DCAssistChart.PlotlyComponents.utils.ploty_constant import FORECASTVOLUMNES

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_forecastvolumes = DjangoDash("forecastvolumes", add_bootstrap_links=True)

app_forecastvolumes.layout = html.Div([

                                dbc.Col([
                                    html.Br(),
                                    html.H5('Case Well Level'),
                                ], style={'textAlign': 'center'}),

                                html.Br(),

                                dcc.Store(id='forecastvolumes_data_id', storage_type='memory'),

                                dbc.Col([
                                    dcc.Dropdown(
                                        id = "forecastvolumes_dropdown_id",
                                        options=[],
                                        multi=True,
                                        clearable=False,
                                        searchable=True,
                                        style={'fontSize': "15px", 'textAlign': 'center'},
                                    ),
                                ], lg=8, className ="mw-100"),
                                
                                html.Br(),

                                dbc.Col([
                                    html.P('This plot window shows total forecast volume within the selected period and against the selected case for all the wells. If no date is selected, the volumes plotted will be displayed from the start of of production to the end of production.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
                                ],className ="mw-100 text-info"),

                                html.Br(),

                                dbc.Col([
                                    dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                                ],className ="mw-100"),

                                html.Br(),

                                dbc.Col(
                                    children=[dcc.DatePickerRange(
                                    id='date_picker_range',
                                    display_format='MM/YYYY',
                                    start_date_placeholder_text='mm/yyyy',
                                    end_date_placeholder_text='mm/yyyy',
                                    clearable=True)],
                                    style={'fontSize': "12px",'textAlign': 'center'}
                                ),

                                html.Br(),


                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_1",
                                    type="circle",
                                    children= [dcc.Graph(id='forecastvolumes_totalprodvsuniqueid', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),
                            ])


@app_forecastvolumes.callback(
    Output('forecastvolumes_dropdown_id','options'),Output('forecastvolumes_dropdown_id','value'),Output('forecastvolumes_data_id','data'),Output('allcases_link_id', 'href'),
    Input('forecastvolumes_data_id','data')
)
def dropdown_options(data, session_state=None):
    forecastvolumes_data = get_forecastvolumes_data(session_state['userid'], session_state['assetdb'], session_state['system'], session_state['allcases'])

    dropdown_options = get_benchmark_dropdown_options(data=forecastvolumes_data, plot_name_constant_details = "FORECASTVOLUMNES['forecastvolumestotalprodvsuniqueid']")

    if len(forecastvolumes_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in dropdown_options]
        selected_dropdown_value = dropdown_options

    else:
        options = []
        selected_dropdown_value = []

    if forecastvolumes_data['system'] == 'true':
        return options,selected_dropdown_value,forecastvolumes_data,f'/chart/forecastvolumesallwells/?userId={forecastvolumes_data["userid"]}&system=true'
    else:
        return options,selected_dropdown_value,forecastvolumes_data,f'/chart/forecastvolumesallwells/?userId={forecastvolumes_data["userid"]}'

# pylint: ignore=unused-argument
@app_forecastvolumes.callback(
    Output(component_id='forecastvolumes_totalprodvsuniqueid', component_property='figure'),
    [Input("forecastvolumes_dropdown_id", "value"), Input('forecastvolumes_data_id', 'data'),
    Input('date_picker_range', 'start_date'), Input('date_picker_range', 'end_date')],
)
def plot_forecastvolumestotalprodvsuniqueid(value, forecastvolumes_data, startdate, enddate):
    return forecastvolumes_totalprodvsuniqueid(dropdown_value=value,forecastvolumes_data=forecastvolumes_data, startdate=startdate, enddate=enddate)

# # pylint: ignore=unused-argument
# @app_forecastvolumes.callback(
#     Output(component_id='multipletotalproductionvscasewelllevel', component_property='figure'),
#     [Input("multiplewell_dropdown_id", "value"), Input('multiplewell_data_id', 'data'),
#     Input('date_picker_range', 'start_date'), Input('date_picker_range', 'end_date')],
# )
# def plot_totalproductionvscasewelllevel(value, multiplewell_data, startdate, enddate):
#     return multipletotalproductionvscasewelllevel(dropdown_value=value,multiplewell_data=multiplewell_data, startdate=startdate, enddate=enddate)

# [{'label': 'LOENINGEN', 'value': 'LOENINGEN'}, {'label': 'BRAMBERGE', 'value': 'BRAMBERGE'}, {'label': 'BODENTEICH', 'value': 'BODENTEICH'}]