from dash import html, dcc, ctx
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

import dash_bootstrap_components as dbc
import dash

from DCAssistChart.DashComponents.utils import get_multiplewell_data
from DCAssistChart.PlotlyComponents.multiplewell_plot import multiplewell_ratevsdate, multiplewell_ratevscum, multiplewell_totalproductionvscasewelllevel

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_multiplewell = DjangoDash("multiplewell", add_bootstrap_links=True)

app_multiplewell.layout = html.Div([

                                dbc.Col([
                                    html.Br(),
                                    html.H5('Unique ID'),
                                ], style={'textAlign': 'center'}),

                                html.Br(),  

                                dcc.Store(id='multiplewell_data_id', storage_type='memory'),

                                dbc.Col([
                                    dcc.Dropdown(
                                        id = "multiplewell_dropdown_id",
                                        options=[],
                                        multi=True,
                                        clearable=False,
                                        searchable=True,
                                        style={'fontSize': "15px", 'textAlign': 'center'},
                                    ),
                                ], lg=8, className ="mw-100"),
                        
                                html.Br(),

                                dbc.Col([
                                    html.P('This window shows production history and forecast cases of sum of all the selected wells.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
                                ],className ="mw-100 text-info"),

                                dbc.Col([
                                    dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                                ],className ="mw-100"),

                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_1",
                                    type="circle",
                                    children= [dcc.Graph(id='multiplewell_ratevsdate', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),

                                html.Br(),

                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_2",
                                    type="circle",
                                    children= [dcc.Graph(id='multiplewell_ratevscum', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),

                                html.Br(),

                                dbc.Col([
                                    html.P('This plot window shows total forecast volume within the selected period and against the multiple wells for all the cases. If no date is selected, the volumes plotted will be displayed from the start of of production to the end of production.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
                                ],className ="mw-100 text-info"),

                                dbc.Col(
                                    children=[dcc.DatePickerRange(
                                    id='date_picker_range',
                                    display_format='MM/YYYY',
                                    start_date_placeholder_text='mm/yyyy',
                                    end_date_placeholder_text='mm/yyyy',
                                    clearable=True)],
                                    style={'fontSize': "12px",'textAlign': 'center'}
                                ),

                                html.Br(),


                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_3",
                                    type="circle",
                                    children= [dcc.Graph(id='multiplewell_totalproductionvscasewelllevel', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),

                            ])


@app_multiplewell.callback(
    Output('multiplewell_dropdown_id','options'),Output('multiplewell_dropdown_id','value'),Output('multiplewell_data_id','data'),Output('allcases_link_id', 'href'),
    Input('multiplewell_data_id','data')
)
def dropdown_options(data, session_state=None):
    multiplewell_data = get_multiplewell_data(session_state['userid'], session_state['assetdb'], session_state['system'], session_state['allcases'])

    if len(multiplewell_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in multiplewell_data.get('uniqueids').keys()]
        selected_dropdown_value = sorted(list(multiplewell_data.get('uniqueids').keys()))

    else:
        options = []
        selected_dropdown_value = []

    if multiplewell_data['system'] == 'true':
        return options,selected_dropdown_value,multiplewell_data,f'/chart/forecastmultiplewellsallwells/?userId={multiplewell_data["userid"]}&system=true'
    else:
        return options,selected_dropdown_value,multiplewell_data,f'/chart/forecastmultiplewellsallwells/?userId={multiplewell_data["userid"]}'

# pylint: ignore=unused-argument
@app_multiplewell.callback(
    Output(component_id='multiplewell_ratevsdate', component_property='figure'),
    [Input('multiplewell_dropdown_id', 'value'), Input('multiplewell_data_id', 'data')],
    )
def plot_multipleratevsdate(value, multiplewell_data):
    return multiplewell_ratevsdate(dropdown_value=value,multiplewell_data=multiplewell_data)

# pylint: ignore=unused-argument
@app_multiplewell.callback(
    Output(component_id='multiplewell_ratevscum', component_property='figure'),
    [Input('multiplewell_dropdown_id', 'value'), Input('multiplewell_data_id', 'data')],
    )
def plot_multipleratevscum(value, multiplewell_data):
    return multiplewell_ratevscum(dropdown_value=value,multiplewell_data=multiplewell_data)

# pylint: ignore=unused-argument
@app_multiplewell.callback(
    Output(component_id='multiplewell_totalproductionvscasewelllevel', component_property='figure'),
    [Input("multiplewell_dropdown_id", "value"), Input('multiplewell_data_id', 'data'),
    Input('date_picker_range', 'start_date'), Input('date_picker_range', 'end_date')],
)
def plot_totalproductionvscasewelllevel(value, multiplewell_data, startdate, enddate):
    return multiplewell_totalproductionvscasewelllevel(dropdown_value=value,multiplewell_data=multiplewell_data, startdate=startdate, enddate=enddate)