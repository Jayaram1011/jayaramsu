from dash import html, dcc, ctx
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

import dash_bootstrap_components as dbc
import dash

from DCAssistChart.DashComponents.utils import get_prodqaqc_data
from DCAssistChart.PlotlyComponents.prodqaqc_plot import prodqaqc_ratechokethpvsdate, prodqaqc_rategorwcvsdate

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_prodqaqc = DjangoDash("prodqaqc", add_bootstrap_links=True)

app_prodqaqc.layout = html.Div([

                                dbc.Col([
                                    html.Br(),
                                    html.H5('Unique ID'),
                                ], style={'textAlign': 'center'}),

                                html.Br(),  

                                dcc.Store(id='prodqaqc_data_id', storage_type='memory'),

                                dbc.Col([
                                    dcc.Dropdown(id='prodqaqc_dropdown_id',
                                    options=[],
                                    placeholder="Select Uniqwell",
                                    style={'fontSize': "15px", 'textAlign': 'center'}),
                                    ], lg=8, className ="mw-100"), 

                                html.Br(),

                                dbc.Col([
                                    html.P('This plot window shows production history and historical well flow parameters for selected well.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
                                ],className ="mw-100 text-info"),

                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_1",
                                    type="circle",
                                    children= [dcc.Graph(id='prodqaqc_ratechokethpvsdate', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),

                                html.Br(),

                                dbc.Col([
                                    dcc.Loading(
                                    id="loading_2",
                                    type="circle",
                                    children= [dcc.Graph(id='prodqaqc_rategorwcvsdate', config=config, style={'width': '100%','display': 'inline-block'})],
                                    )
                                ]),

                            ])

@app_prodqaqc.callback(
    Output('prodqaqc_dropdown_id','options'),Output('prodqaqc_dropdown_id','value'),Output('prodqaqc_data_id','data'),
    Input('prodqaqc_data_id','data')
)
def dropdown_options(data, session_state=None):
    prodqaqc_data = get_prodqaqc_data(session_state['userid'], session_state['assetdb'], session_state['system'], session_state['failed'])

    if len(prodqaqc_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in prodqaqc_data.get('uniqueids').keys()]
        selected_dropdown_value = sorted(list(prodqaqc_data.get('uniqueids').keys()))[0]

    else:
        options = []
        selected_dropdown_value = ''

    return options,selected_dropdown_value,prodqaqc_data

# pylint: ignore=unused-argument
@app_prodqaqc.callback(
    Output(component_id='prodqaqc_ratechokethpvsdate', component_property='figure'),
    [Input('prodqaqc_dropdown_id', 'value'), Input('prodqaqc_data_id', 'data')],
    )
def plot_prodqaqcratechokethpvsdate(value, prodqaqc_data):
    return prodqaqc_ratechokethpvsdate(dropdown_value=value,prodqaqc_data=prodqaqc_data)

# pylint: ignore=unused-argument
@app_prodqaqc.callback(
    Output(component_id='prodqaqc_rategorwcvsdate', component_property='figure'),
    [Input('prodqaqc_dropdown_id', 'value'), Input('prodqaqc_data_id', 'data')],
    )
def plot_prodqaqcrategorwcvsdate(value, prodqaqc_data):
    return prodqaqc_rategorwcvsdate(dropdown_value=value,prodqaqc_data=prodqaqc_data)