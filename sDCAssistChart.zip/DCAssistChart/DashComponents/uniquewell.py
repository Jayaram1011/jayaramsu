from dash import html, dcc, ctx
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

import dash_bootstrap_components as dbc
import dash

from DCAssistChart.DashComponents.utils import get_uniquewell_data, get_outliers_data, reset_outlier_data, update_selected_outlier_data, update_selected_dates_decline_period, select_box_data
from DCAssistChart.PlotlyComponents.uniquewell_plot import uniquewell_ratevsdate, uniquewell_ratevscum, uniquewell_divscasewelllevel, uniquewell_bparametervscasewelllevel, uniquewell_totalproductionvscasewelllevel

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_uniquewell = DjangoDash("uniquewell", add_bootstrap_links=True)

app_uniquewell.layout = html.Div([

        dbc.Modal(
            [
                dbc.ModalHeader(
                    dbc.ModalTitle("Dismissing"), close_button=False
                ),
                dbc.ModalBody(id="modal-body-id"
                ),
                dbc.ModalFooter(dbc.Button("Close", id="close-dismiss")),
            ],
            id="modal-dismiss",
            keyboard=False,
            backdrop="static",
        ),
        dbc.Col([
            html.Br(),
            html.H5('Unique ID'),
        ], style={'textAlign': 'center'}),

        html.Br(),  

        dcc.Store(id='uniquewell_data_id', storage_type='memory'),
        dcc.Store(id='uniquewell_selected_data_id', storage_type='memory'),
        dcc.Store(id='uniquewell_outlier_data_id', storage_type='memory'),

        dbc.Col([
            dcc.Dropdown(id='uniquewell_dropdown_id',
                    options=[],
                    placeholder="Select Uniqwell",
                    style={'fontSize': "15px", 'textAlign': 'center'}),
            ], lg=8, className ="mw-100"), 

        html.Br(),

        dbc.Col([
        html.P('This plot window shows forecast rates and forecast parameter values for different forecast cases for selected wells.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
        html.P('Enlarge the Rate vs Date and Rate vs Cumulative Volume to see comparison with the benchmark case.',style={'fontSize': "17px", 'textAlign': 'center','background-color': '#FFFF00'}),
        ],className ="mw-100 text-info"),

        html.Br(),

        dbc.Col([
                dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                ],className ="mw-100"),

        html.Br(),

        dbc.Row([
                    dcc.Loading(
                        id="loading_1",
                        type="circle",
                        children= [
                                    dcc.Link(children=[dcc.Graph(id='uniquewell_ratevsdate', config=config)], id='uniquewellratevsdate_link',href='#', style={'width': '50%','display': 'inline-block'}), 
                                    dcc.Link(children=[dcc.Graph(id='uniquewell_ratevscum', config=config)], id='uniquewellratevscum_link',href='#', style={'width': '50%','display': 'inline-block'})
                                ],
                        )
        ]),

        html.Br(),

        dbc.Row([
                    dcc.Loading(
                        id="loading_2",
                        type="circle",
                        children= [
                                    dcc.Link(children=[dcc.Graph(id='uniquewell_divscasewelllevel', config=config)], id='uniquewelldivscasewelllevel_link',href='#', style={'width': '50%','display': 'inline-block'}), 
                                    dcc.Link(children=[dcc.Graph(id='uniquewell_bparametervscasewelllevel', config=config)], id='uniquewellbparametervscasewelllevel_link',href='#', style={'width': '50%','display': 'inline-block'})
                                ],
                        )
        ]),

        html.Br(),

        dbc.Col([
                    dcc.Loading(
                        id="loading_3",
                        type="circle",
                        children= [
                                    dcc.Link(children=[dcc.Graph(id='uniquewell_totalproductionvscasewelllevel', config=config )], id='uniquewelltotalproductionvscasewelllevel_link',href='#', style={'width': '100%','display': 'inline-block'}), 
                                ],
                        )
        ]),

        html.Br(),

        dbc.Button("Reset", id="submit-val1", n_clicks=0, style={'display':'none'}),
        dbc.Button("Outlier", id="submit-val2", n_clicks=0, style={'display':'none'}),
        dbc.Button("Update Decline Period", id="submit-val3", n_clicks=0, style={'display':'none'}),
    ],className="container-fluid")


@app_uniquewell.callback(
    Output('uniquewell_dropdown_id','options'),Output('uniquewell_data_id','data'),Output('allcases_link_id', 'href'), Output('uniquewellratevsdate_link', 'href'), Output('uniquewellratevscum_link', 'href'), Output('uniquewelldivscasewelllevel_link', 'href'), Output('uniquewellbparametervscasewelllevel_link', 'href'),
    Input('uniquewell_data_id','data')
)
def dropdown_options(data, session_state=None):
    uniquewell_data = get_uniquewell_data(session_state['userid'], session_state['assetdb'], session_state['system'],session_state['allcases'])

    if len(uniquewell_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in uniquewell_data.get('uniqueids').keys()]
    else:
        options = []

    if uniquewell_data['allcases'] == True:
        if uniquewell_data['system'] == 'true':
            return options,uniquewell_data,f'/chart/forecastuniquewellallwells/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewellallwellsratevsdate/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewellallwellsratevscum/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewellallwellsdivscasewelllevel/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewellallwellsbparametervscasewelllevel/?userId={uniquewell_data["userid"]}&system=true'
        else:
            return options,uniquewell_data,f'/chart/forecastuniquewellallwells/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellallwellsratevsdate/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellallwellsratevscum/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellallwellsdivscasewelllevel/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellallwellsbparametervscasewelllevel/?userId={uniquewell_data["userid"]}'

    else:
        if uniquewell_data['system'] == 'true':
            return options,uniquewell_data,f'/chart/forecastuniquewellallwells/?userId={uniquewell_data["userid"]}&system=true',  f'/chart/forecastuniquewellratevsdate/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewellratevscum/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewelldivscasewelllevel/?userId={uniquewell_data["userid"]}&system=true', f'/chart/forecastuniquewellbparametervscasewelllevel/?userId={uniquewell_data["userid"]}&system=true'
        else:
            return options,uniquewell_data,f'/chart/forecastuniquewellallwells/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellratevsdate/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellratevscum/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewelldivscasewelllevel/?userId={uniquewell_data["userid"]}', f'/chart/forecastuniquewellbparametervscasewelllevel/?userId={uniquewell_data["userid"]}'


    # return options, uniquewell_data
    
# @app_uniquewell.expanded_callback(
#     [Output('dropdown_uniqueid', 'options'),Output('dropdown_uniqueid', 'value'),Output('link', 'href'),Output('link_1', 'href'),Output('link_2', 'href'),Output('link_3', 'href'),Output('link_4', 'href')],
#     [Input('target_id', 'value')])
# def update_date_dropdown(value,**kwargs):
#     json_object = json.loads(value)
#     userid = json_object.get('userid')
#     if len(json_object.get('uniqueids')) != 0:
#         options = [{'label': i, 'value': i} for i in json_object.get('uniqueids').keys()]
#         selected_value = sorted(list(json_object.get('uniqueids').keys()))[0]
#     else:
#         options = []
#         selected_value = ''
#     if json_object.get('allcase') == True:
#         if json_object.get('system') == 'true':
#             return options,selected_value,f'/charts/ratevsdateallwell/?userId={userid}&system=true',f'/charts/ratevscumallwell/?userId={userid}&system=true',f'/charts/divscaseallwell/?userId={userid}&system=true',f'/charts/bvscaseallwell/?userId={userid}&system=true',f'/charts/forecastuniquewellallwell/?userId={userid}&system=true'
#         else:
#             return options,selected_value,f'/charts/ratevsdateallwell/?userId={userid}',f'/charts/ratevscumallwell/?userId={userid}',f'/charts/divscaseallwell/?userId={userid}',f'/charts/bvscaseallwell/?userId={userid}',f'/charts/forecastuniquewellallwell/?userId={userid}'
#     else:
#         if json_object.get('system') == 'true':
#                 return options,selected_value,f'/charts/ratevsdate/?userId={userid}&system=true',f'/charts/ratevscum/?userId={userid}&system=true',f'/charts/divscase/?userId={userid}&system=true',f'/charts/bvscase/?userId={userid}&system=true',f'/charts/forecastuniquewellallwell/?userId={userid}&system=true'
#         else:
#                 return options,selected_value,f'/charts/ratevsdate/?userId={userid}',f'/charts/ratevscum/?userId={userid}',f'/charts/divscase/?userId={userid}',f'/charts/bvscase/?userId={userid}',f'/charts/forecastuniquewellallwell/?userId={userid}'
   

#pylint: ignore=unused-argument
@app_uniquewell.callback(
    Output('uniquewell_outlier_data_id','data'), Output(component_id='uniquewell_ratevsdate', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    State('uniquewell_outlier_data_id','data'))
def plot_ratevsdate(value, uniquewell_data, session_state=None):
    outlier_data =  get_outliers_data(assetdb = uniquewell_data['assetdb'], userid=uniquewell_data['userid'])
    return outlier_data, uniquewell_ratevsdate(dropdown_value=value,uniquewell_data=uniquewell_data,outlier_data=outlier_data)

app_uniquewell.clientside_callback(
    """        
        function(figure, uniquewell_data) {
            doc = window.frames.document;

            if(doc.body.textContent.indexOf("Decline-Period")!==-1){

                d = doc.querySelector("div.modebar-container div");
        
                dd = doc.createElement("div");
                
                dd.className = "modebar-group";

                if (!uniquewell_data["system"]) {
                    if (!doc.getElementById("reset-icon")) {
                        a1 = doc.createElement("a");
                        a1.rel = "tooltip";
                        a1.id = "reset-icon"
                        a1.className = "modebar-btn";
                        a1.setAttribute('data-title', 'Reset');
            
                        img1 = doc.createElement("img");
                        img1.src = "https://" + uniquewell_data["domain"] + "/reset.svg";
            
                        a1.appendChild(img1);
            
                        dd.appendChild(a1);
            
                        d.appendChild(dd);
        
                        a1.onclick = function () { window.frames.document.getElementById("submit-val1").click()}
                    };
            
                    if (!doc.getElementById("delete-icon")) {
                        a2 = doc.createElement("a");
                        a2.rel = "tooltip";
                        a2.id = "delete-icon"
                        a2.className = "modebar-btn";
                        a2.setAttribute('data-title', 'Outlier');
            
                        img2 = doc.createElement("img");
                        img2.src = "https://" + uniquewell_data["domain"] + "/remove.svg";
            
                        a2.appendChild(img2);
            
                        dd.appendChild(a2);
            
                        d.appendChild(dd);
        
                        a2.onclick = function () { window.frames.document.getElementById("submit-val2").click()}
                    };
            
            	    if (!doc.getElementById("update-period-icon")) {
                        a3 = doc.createElement("a");
                        a3.rel = "tooltip";
                        a3.id = "update-period-icon"
                        a3.className = "modebar-btn";
                        a3.setAttribute('data-title', 'Update Decline Period');
            
                        img3 = doc.createElement("img");
                        img3.src = "https://" + uniquewell_data["domain"] + "/update_decline_period.svg";
            
                        a3.appendChild(img3);
            
                        dd.appendChild(a3);
            
                        d.appendChild(dd);
        
                        a3.onclick = function () { window.frames.document.getElementById("submit-val3").click()}
                    };
                };
            };

        return window.dash_clientside.no_update;
        }
    """,
    Output('uniquewell_ratevsdate', 'id'),
    Input('uniquewell_ratevsdate', 'figure'), Input('uniquewell_data_id', 'data')
)


@app_uniquewell.callback(
    Output('uniquewell_selected_data_id','data'),
    [Input('uniquewell_ratevsdate','selectedData'),Input('uniquewell_dropdown_id', 'value'), 
    Input('uniquewell_data_id', 'data')])
def select_data(selectedData, value, uniquewell_data):
    return select_box_data(selectedData, value, uniquewell_data, 'Rate')

@app_uniquewell.callback(
    Output("modal-dismiss", "is_open"),Output("modal-body-id", "children"),
    Output("close-dismiss", "n_clicks"),Output('uniquewell_selected_data_id','clear_data'),Output('uniquewell_dropdown_id','value'),
    Input("submit-val1", "n_clicks"),Input("submit-val2", "n_clicks"), Input("submit-val3", "n_clicks"),
    Input("close-dismiss", "n_clicks"),Input('uniquewell_dropdown_id', 'value'),
    [State('uniquewell_selected_data_id', 'data'),State("uniquewell_data_id","data"),State('uniquewell_outlier_data_id','data'), State("modal-dismiss", "is_open")],
    prevent_initial_call=True
)
def toggle_modal(n_open_reset, n_open_outlier, n_open_decline, n_close, value, uniquewell_selected_data, uniquewell_data, uniquewell_outlier_data, is_open):

    ctx = dash.callback_context

    if ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val1":
        n_open = n_open_reset
        uniquewell_selected_data["selected_dates"] = True
    elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val2":
        n_open = n_open_outlier
    elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val3":
        n_open = n_open_decline
    else:
        n_open = 0

    if uniquewell_selected_data:
        if (uniquewell_selected_data["selected_dates"] and n_open) or n_close:

            if n_close:                    
                return not is_open , dash.no_update, 0, True, value
            else:
                if ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val1":
                    msg = reset_outlier_data(uniqueid = value, asset_db = uniquewell_data['assetdb'], user_id = uniquewell_data['userid'])
                    return not is_open , msg, 0, False, value

                elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val2":
                    msg = update_selected_outlier_data(uniqueid = value, asset_db = uniquewell_selected_data['assetdb'], user_id = uniquewell_selected_data['user_id'], selected_date_list = uniquewell_selected_data['selected_dates'], selected_column = uniquewell_selected_data['selected_column'])

                elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val3":
                    msg = update_selected_dates_decline_period(uniqueid = value, asset_db = uniquewell_selected_data['assetdb'], user_id = uniquewell_selected_data['user_id'], selected_date_list = uniquewell_selected_data['selected_dates'])

                return not is_open , msg, 0, False, dash.no_update

    else:
        if n_open or n_close:
            msg = "Select Date using box-select"
            return not is_open , msg, 0, dash.no_update, dash.no_update
        return is_open, dash.no_update, 0, dash.no_update, dash.no_update

# pylint: ignore=unused-argument
@app_uniquewell.callback(
    Output(component_id='uniquewell_ratevscum', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    )
def plot_ratevscum(value, uniquewell_data):
    return uniquewell_ratevscum(dropdown_value=value,uniquewell_data=uniquewell_data)

# pylint: ignore=unused-argument
@app_uniquewell.callback(
    Output(component_id='uniquewell_divscasewelllevel', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    )
def plot_divscasewelllevel(value, uniquewell_data):
    return uniquewell_divscasewelllevel(dropdown_value=value,uniquewell_data=uniquewell_data)

# pylint: ignore=unused-argument
@app_uniquewell.callback(
    Output(component_id='uniquewell_bparametervscasewelllevel', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    )
def plot_bparametervscasewelllevel(value, uniquewell_data):
    return uniquewell_bparametervscasewelllevel(dropdown_value=value,uniquewell_data=uniquewell_data)

# pylint: ignore=unused-argument
@app_uniquewell.callback(
    Output(component_id='uniquewell_totalproductionvscasewelllevel', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    )
def plot_totalproductionvscasewelllevel(value, uniquewell_data):
    return uniquewell_totalproductionvscasewelllevel(dropdown_value=value,uniquewell_data=uniquewell_data)

 