import logging
import pandas as pd

from DCAssistChart.dbqueries import outlier_db_datalist
from dcausers.helper import get_userwells
from runalgorithm.helper import get_active_and_failed_runs_for_wells, get_active_runs_for_wells, get_saved_runs_for_wells, get_latest_run_for_wells
from spotfire.views import delete_outlier_records, set_update_outlier, update_startdate_enddate_records

logger = logging.getLogger(__name__)

class DBConnection:

    def get_algorithmruns(self, assetdb, userid):
        args = get_latest_run_for_wells(assetdb, userid)
        return args.values('well_id', 'runid', 'welltype')

    def get_list_of_latest_run_wellid(self, ars, well_type=False):
        df = pd.DataFrame(list(ars))
        df = df.drop_duplicates(subset="well_id", keep="first")
        if well_type:
            df['merged_field'] = df['runid']+','+df['welltype']
            return dict(zip(df.well_id, df['merged_field']))
        return dict(zip(df.well_id, df.runid))

    def get_list_of_wellid(self, ars, well_type=False):
        df = pd.DataFrame(list(ars))
        if well_type:
            df['merged_field'] = df['runid']+','+df['welltype']
            return dict(zip(df.well_id, df['merged_field']))
        return dict(zip(df.well_id, df.runid))

    def get_value_json(self, userid, list_of_wellid, system=False):
        value = {}
        value['userid'] = userid
        value['uniqueids'] = list_of_wellid
        if system:
            value['system'] = 'true'
        return value

    def activewellsoutputdirwithnd(self, assetdb, userid):
        try:
            ars = get_active_and_failed_runs_for_wells(assetdb, userid).values('well_id', 'runid', 'welltype')
            list_of_wellid = []
            if ars:
                list_of_wellid = self.get_list_of_latest_run_wellid(ars, True)
            return self.get_value_json(userid, list_of_wellid)
        except Exception as e:
            logger.error(e, exc_info=True)

    def activewellsoutputdirwithndsys(self, assetdb, userid):
        try:
            user_well_ids = get_userwells(assetdb, userid)
            ars = get_saved_runs_for_wells(assetdb, user_well_ids)
            list_of_wellid = []
            if ars:
                list_of_wellid = self.get_list_of_wellid(ars, True)
            return self.get_value_json(userid, list_of_wellid, True)
        except Exception as e:
            logger.error(e, exc_info=True)

    def activewellsoutputdir_with_nd(self, assetdb, userid):
        try:
            ars = get_active_runs_for_wells(assetdb, userid).values('well_id', 'runid', 'welltype')
            list_of_wellid = []
            if ars:
                list_of_wellid = self.get_list_of_latest_run_wellid(ars, True)
            return self.get_value_json(userid, list_of_wellid)
        except Exception as e:
            logger.error(e, exc_info=True)
        
    def activewellsoutputdirsys(self, assetdb, userid, failed=None):
        try:
            user_well_ids = get_userwells(assetdb, userid)
            saved_ars = get_saved_runs_for_wells(assetdb, user_well_ids)
            if not failed:
                ars = filter(lambda item: item["welltype"]=='PD' , saved_ars)
            else:
                ars = saved_ars
            list_of_wellid = []
            if ars:
                list_of_wellid = self.get_list_of_wellid(ars)
            return self.get_value_json(userid, list_of_wellid, True)
        except Exception as e:
            logger.error(e, exc_info=True)

    def activewellsoutputdir(self,assetdb, userid, failed=None):
        try:
            if failed:
                ars = self.get_algorithmruns(assetdb, userid)  
            else:
                ars = get_active_runs_for_wells(assetdb, userid).filter(welltype="PD").values('well_id', 'runid', 'welltype')
            list_of_wellid = []
            if ars:
                list_of_wellid = self.get_list_of_latest_run_wellid(ars)
            return self.get_value_json(userid, list_of_wellid)
        except Exception as e:
            logger.error(e, exc_info=True)

    def  get_outlier_db_data(self, assetdb, userid):     
        try:
            outliers = outlier_db_datalist(assetdb, userid)
            dates = dict()
            for outlier in outliers:
                if outlier['UNIQUEID'] in dates:
                    temp = dates[outlier['UNIQUEID']]
                    dd = temp.append(str(outlier['date']))
                    dates[outlier['UNIQUEID']] = temp
                else:
                    dates[outlier['UNIQUEID']] = [str(outlier['date']),]
            return dates
        except Exception as e:
            logger.error(e, exc_info=True)


def delete_outlier_records_data(asset_db, user_id, uniqueid):
    delete_outlier_records(asset_db, user_id, uniqueid)

def update_selected_outlier_for_next_runanalysis_data(asset_db, uniqueid, user_id, selected_column, selected_date_list):
    set_update_outlier(asset_db, uniqueid, user_id, selected_column, selected_date_list)

def update_startdate_enddate_decline_period_data(decline_start_date, decline_end_date, asset_db, uniqueid, user_id):
    update_startdate_enddate_records(decline_start_date, decline_end_date, asset_db, uniqueid, user_id)

