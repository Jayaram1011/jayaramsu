from inputdata.models import Outlier
from outputdata.models import Units
from masterdata.models import Well, ProductionData, WellTestData

def get_cluster(value, assetdb):
    first_well = list(value.get('uniqueids').keys())[0]
    well_data = Well.objects.using(assetdb).get(UNIQUEID=first_well)
    return well_data.cluster

def get_units(assetdb):
    units = Units.objects.using(assetdb).all().values().first()
    return units if units else {}

def outlier_db_datalist(assetdb, userid):
    outlier_data = list(Outlier.objects.using(assetdb).filter(user_id=userid, Rate=True).values('UNIQUEID','date'))
    return outlier_data

def get_prodqaqc_ratechokethpvsdate_data(assetdb, uniqueid):
    return ProductionData.objects.using(assetdb).filter(UNIQUEID_id=uniqueid).values('M_DATE', 'OIL', 'PROD_DAYS', 'BEAN', 'THP', 'UNIQUEID_id')

def get_prodqaqc_rategorwcvsdate_data(assetdb, uniqueid):
    return ProductionData.objects.using(assetdb).filter(UNIQUEID_id=uniqueid).values('M_DATE', 'OIL', 'PROD_DAYS', 'WATER', 'GAS', 'BEAN')

def get_prodqaqcwelltestdata_datavalidation_productiondata(assetdb, uniqueid):
    return ProductionData.objects.using(assetdb).filter(UNIQUEID_id=uniqueid).values('M_DATE', 'OIL', 'PROD_DAYS', 'WATER', 'GAS')

def get_prodqaqcwelltestdata_datavalidation_welldata(assetdb, uniqueid):
    return WellTestData.objects.using(assetdb).filter(UNIQUEID_id=uniqueid).values('TEST_DATE', 'OIL', 'BSW', 'GAS')
 